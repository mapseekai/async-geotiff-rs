# D1 native nearest follow-up

Before binary: previous optimization (optimization-20260930-procedure.tar.gz).
After: before + continuation.patch. combined.patch is against base HEAD.
meta.json records the executable and source SHA-256 values. Binaries and the
five original COG datasets are excluded. No dependencies or benchmarks are
installed by these scripts.

Use the original data directory, TiTiler Python environment and Playwright setup.
Build the temporary example titiler_comparison_bench.rs with default features:
    cargo build --release --example titiler_comparison_bench
Save binaries as before-server / after-server in this procedure directory.
Keep the original serve binary as the shared /data Range origin. Remove the
temporary example after building. Do not compile during measurement.

With ports 18980 and 18981 unused, run using the original TiTiler .venv Python:
    python paired_bench.py > paired-progress.log 2>&1
    python steady.py > steady.log 2>&1
    python steady_summary.py
    python summarize.py

paired_bench.py requires fresh paired/before and paired/after output directories.
steady.py uses this directory's binary pair and stores results under steady/.
recheck.py uses the two historical binaries at /private/tmp/raster-style-opt6
to reassess the original +15% observation. Adjust paths if reconstructing.
steady_summary.py expects both diagnostic runs and resamples 30 whole process
pairs, rather than treating the 600 repeated warm responses as independent.
All startup is excluded; OS cache is retained; machine is not isolated.

For independent stage profiling only, build each version with perf-tracing,
save profile-before-server and profile-after-server, and run profile_stages.py.
Profile logs exclude each process's first request. Do not compare logged profile
latency as if it were the uninstrumented HTTP benchmark.

prepare_results.py and summarize.py write structured results into the repo's
documentation directory at the original absolute path. publish.py appends the
report and packages artifacts; it is not idempotent. Preserve existing results
before rerunning publication.
