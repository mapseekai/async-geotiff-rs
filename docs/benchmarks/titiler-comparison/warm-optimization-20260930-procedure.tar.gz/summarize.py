import collections,gzip,hashlib,json,pathlib,statistics,tarfile
R=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/zhang/code/async-geotiff-rs')
items=json.loads((R/'datasets.json').read_text());names={x['file']:f'D{i+1}' for i,x in enumerate(items)}
raw=[];groups=collections.defaultdict(list);pixels=collections.defaultdict(set);counts={};coords={}
assert (R/'paired-progress.log').read_text().rstrip().endswith('COMPLETE')
for label in ['before','after']:
 records=[json.loads(s) for s in (R/'paired'/label/'raw.jsonl').read_text().splitlines()]
 assert dict(collections.Counter(x['scenario'] for x in records))=={'single':100,'viewport':100,'burst32':50}
 counts[label]=collections.Counter()
 coords[label]={}
 for r in records:
  z=r.get('zoom',r.get('coord',[None])[0]);groups[(r['scenario'],r['file'],z,r['phase'],label)].append(r)
  coords[label][(r['scenario'],r['file'],z,r['phase'],r['round'])]=r.get('coords',r.get('coord'))
  tiles=[r] if r['scenario']=='single' else r['tiles']
  for tile in tiles:
   assert tile['status']==200 and 'error' not in tile and tile['width']==tile['height']==256 and tile['visible_fraction']>0
   counts[label][r['scenario']]+=1
  if r['scenario']=='viewport':assert r['network_requests']==16 and r['cache_hits']==0 and r['visible_tiles']==16 and r['errors']==0
  else:
   cs=[r['coord']] if r['scenario']=='single' else r['coords']
   for coord,t in zip(cs,tiles):pixels[(r['file'],tuple(coord))].add(t['pixel_sha256'])
  raw.append(dict(r,version=label))
 assert sum(counts[label].values())==3300
assert coords['before']==coords['after']
assert all(len(v)==1 for v in pixels.values())
for item in items:
 key=hashlib.sha256(item['file'].encode()).hexdigest()[:12]
 assert (R/'paired/before/samples'/f'{key}-rust.png').read_bytes()==(R/'paired/after/samples'/f'{key}-rust.png').read_bytes()
rows=[]
for scenario,file,z,phase in sorted({k[:4] for k in groups}):
 metric='elapsed_ms' if scenario=='single' else 'load_ms';before=groups[(scenario,file,z,phase,'before')];after=groups[(scenario,file,z,phase,'after')]
 a=statistics.median(x[metric] for x in before);b=statistics.median(x[metric] for x in after)
 rows.append(dict(scenario=scenario,dataset=names[file],file=file,zoom=z,phase=phase,pairs=len(before),before_ms=a,after_ms=b,change_percent=(b/a-1)*100,before_response_bytes=statistics.median(x.get('total_bytes',x.get('bytes')) for x in before),after_response_bytes=statistics.median(x.get('total_bytes',x.get('bytes')) for x in after)))
assert len(rows)==40
assert all(r['before_response_bytes']==r['after_response_bytes'] for r in rows)
checks={'all_6600_responses_valid':True,'all_browser_cache_checks_passed':True,'matching_coordinates':True,'all_single_and_burst_pixels_exact_across_versions_and_repetitions':True,'center_png_bytes_exact':True,'response_sizes_unchanged':True}
summary={'environment':json.loads((R/'meta.json').read_text()),'datasets':items,'rows':rows,'request_counts':counts,'checks':checks}
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
dest=repo/'docs/benchmarks/titiler-comparison';(dest/'warm-optimization-20260930-results.json').write_text((R/'summary.json').read_text())
with (dest/'warm-optimization-20260930-raw.jsonl.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in raw).encode())
