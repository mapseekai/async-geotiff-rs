# Large-COG procedure (2026-09-30)

This archive preserves the documented harness with only the Rust request syntax
changed to Raster Style Q2 (`version=2.0&type=rgb&method=linear`). Bands, repeated
rescale values, nearest sampling, PNG, coordinates, repetitions and caches are
unchanged. TiTiler requests remain legacy-compatible.

On the original benchmark machine, extract into a fresh scratch directory, then:

```sh
# From /Users/zhang/code/async-geotiff-rs:
cp /absolute/scratch/rust_server.rs examples/titiler_comparison_bench.rs
cargo build --release --example serve --example titiler_comparison_bench
cp target/release/examples/titiler_comparison_bench /absolute/scratch/rust-server
rm examples/titiler_comparison_bench.rs
# Ports 18980, 18981, 18982 must be unused. From the scratch directory:
PYTHONWARNINGS=ignore /Users/zhang/code/titiler/.venv/bin/python run_comparison.py > progress.log 2>&1
PYTHONWARNINGS=ignore /Users/zhang/code/titiler/.venv/bin/python summarize_results.py
```

The Rust wiring uses the original example router with a shared Range origin;
no renderer fork or output cache is introduced. The harness reads the existing
five files in `/Users/zhang/code/async-geotiff-rs/data`; never run prepare.py or
replace these datasets. The browser loads installed Playwright from tasklane.
The report generator's environment prose is historical; verify the actual
manifest and update that prose when rerunning on a different environment.

The same-session legacy control used the original stored rust-server whose
SHA-256 is 2feb3eb28025b731085c0e0b5261883ccb31cf57a56ffc6f5b931a643077464e,
with the original legacy tile_path from harness.legacy.py and identical rounds.
It was not rebuilt from current HEAD. Its original source hashes and tracked
working-tree patch are preserved separately. The control still uses the current
shared Range origin; startup is excluded. Current and control runs are sequential,
not randomized cross-version pairs. Do not interpret timing differences as an
isolated style-engine microbenchmark or statistical significance test.

The final repository report adds before/after interpretation to the generated
report; finish_results.py records the historical comparison in structured JSON.
manifest.json, source-hashes.json, working-tree.patch and build.log identify the
current measured source and build. PNG samples are compared by decoded pixels,
not compressed bytes. Use raw.jsonl.gz for per-request timings and pixel hashes.
