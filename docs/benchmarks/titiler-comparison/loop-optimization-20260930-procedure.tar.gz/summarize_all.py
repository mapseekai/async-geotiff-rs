import json,pathlib
from summarize import summarize
R=pathlib.Path(__file__).resolve().parent
http=json.loads((R/'final-http/http-pairs.json').read_text());out={"http":{},"validation":{}}
for kernel in ['nearest','bilinear']:
 rows=[x for x in http if x['kernel']==kernel];p=R/f'http-{kernel}.json';p.write_text(json.dumps(rows))
 part=summarize(R/'cpu-final-pairs.json',p)
 out['cpu']=part['cpu'];out['encode_only']=part['encode_only'];out['http'][kernel]=part['http'];out['validation'][kernel]=part['validation']
out['pixel_validation']=json.loads((R/'pixel-validation/results.json').read_text())
(R/'results.json').write_text(json.dumps(out,indent=2)+'\n')
for x in out['cpu']:print('CPU',x)
for kernel,rows in out['http'].items():
 for x in rows:print(kernel,x['scenario'],x['file'],x)
