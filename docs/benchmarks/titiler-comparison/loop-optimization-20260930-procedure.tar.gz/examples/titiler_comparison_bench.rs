// Benchmark wiring only; the HTTP router and renderer are the original project code.
use async_geotiff::io::{BlockCache, CacheConfig};
use std::{path::PathBuf, sync::Arc};
#[path = "/Users/zhang/code/async-geotiff-rs/examples/serve/server.rs"]
mod server;
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    if std::env::var_os("RUST_LOG").is_some_and(|v| v != "off") {
        tracing_subscriber::fmt()
            .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
            .with_ansi(false)
            .init();
    }
    let data = PathBuf::from("/Users/zhang/code/async-geotiff-rs/data");
    let mut names: Vec<String> = std::fs::read_dir(data)?
        .filter_map(Result::ok)
        .map(|e| e.file_name().to_string_lossy().into_owned())
        .filter(|n| {
            let n = n.to_lowercase();
            n.ends_with(".tif") || n.ends_with(".tiff")
        })
        .collect();
    names.sort();
    let state = server::AppState::new(
        None,
        None,
        names,
        "http://127.0.0.1:18980",
        Arc::new(BlockCache::new(CacheConfig::default())),
    );
    let listener = tokio::net::TcpListener::bind("127.0.0.1:18981").await?;
    axum::serve(listener, server::router(state)).await?;
    Ok(())
}
