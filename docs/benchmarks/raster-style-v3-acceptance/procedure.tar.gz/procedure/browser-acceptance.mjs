const fs = await import("node:fs/promises");
const assert = (await import("node:assert/strict")).default;
const out = "/tmp/raster-q3-acceptance-20261019";
const task = await taskSpace("Raster Style Q3 acceptance rerun");
const page = task.page("p1");
const results = [];
await page.cdp("Emulation.clearDeviceMetricsOverride");
async function completed(expected) {
  await page.waitForFunction((wanted) => performance.getEntriesByType("resource").some(e => e.name.includes("/tiles/") && e.responseStatus === 200 && Object.entries(wanted).every(([key,value]) => new URL(e.name).searchParams.get(key) === value)), expected, {timeout:30000});
}
async function record(viewer, scenario, expected = {}) {
  await completed(expected);
  if (viewer === "leaflet") await page.waitForSelector("#map img.leaflet-tile-loaded",{state:"visible"});
  if (viewer === "openlayers") await page.waitForFunction(()=>{const c=document.querySelector("#map canvas");if(!c)return false;const a=c.getContext("2d").getImageData(0,0,c.width,c.height).data;for(let i=3;i<a.length;i+=4096)if(a[i])return true;return false;},undefined,{timeout:30000});
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data = await page.evaluate(async (wanted) => {
    const entries = performance.getEntriesByType("resource").filter(e => e.name.includes("/tiles/") && e.responseStatus === 200 && Object.entries(wanted).every(([key,value]) => new URL(e.name).searchParams.get(key) === value));
    let url,response,bytes,bitmap,visible;
    for(const entry of [...entries].reverse().slice(0,16)) {
      url=entry.name;response=await fetch(url,{cache:"no-store"});bytes=await response.arrayBuffer();
      bitmap=await createImageBitmap(new Blob([bytes],{type:response.headers.get("Content-Type")}));
      const canvas=document.createElement("canvas");canvas.width=bitmap.width;canvas.height=bitmap.height;
      const ctx=canvas.getContext("2d");ctx.drawImage(bitmap,0,0);const pixels=ctx.getImageData(0,0,bitmap.width,bitmap.height).data;
      visible=0;for(let i=3;i<pixels.length;i+=4)if(pixels[i])visible++;
      if(visible)break;
    }
    const hash=[...new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))].map(x=>x.toString(16).padStart(2,"0")).join("");
    const errors=performance.getEntriesByType("resource").filter(e=>e.name.includes("/tiles/") && e.responseStatus>=400).map(e=>({url:e.name,status:e.responseStatus}));
    return {url,status:response.status,width:bitmap.width,height:bitmap.height,bytes:bytes.byteLength,sha256:hash,visibleFraction:visible/(bitmap.width*bitmap.height),tileErrors:errors,pageErrors:window.__qa.errors,unhandled:window.__qa.unhandled,viewport:innerWidth,bodyWidth:document.body.scrollWidth,rootWidth:document.documentElement.scrollWidth,navigationOverlap:location.pathname==="/maplibre" && document.getElementById("style-form").getBoundingClientRect().right>document.querySelector(".maplibregl-ctrl-top-right .maplibregl-ctrl-group").getBoundingClientRect().left,layoutOverflow:[...document.querySelectorAll("#style-form input,#style-form select,#style-form button,#style-form a,.status")].filter(e=>e.getClientRects().length).map(e=>({id:e.id||e.tagName,left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right})).filter(e=>e.left<0 || e.right>innerWidth+0.5),expressionDisabled:document.getElementById("bidx").disabled};
  },expected);
  const params=new URL(data.url).searchParams;
  assert.equal(params.get("version"),"3.0");
  assert.equal(params.has("format"),false);assert.equal(params.has("tilesize"),false);
  assert.equal(data.status,200);assert.equal(data.tileErrors.length,0);assert.equal(data.pageErrors.length,0);assert.equal(data.unhandled.length,0);
  assert.ok(data.visibleFraction>0);assert.equal(data.bodyWidth<=data.viewport,true);assert.ok(data.rootWidth<=data.viewport,JSON.stringify(data));assert.deepEqual(data.layoutOverflow,[]);assert.equal(data.navigationOverlap,false);
  results.push({viewer,scenario,...data});
  await fs.writeFile(`${out}/browser-results.json`,JSON.stringify(results,null,2));
  console.log(viewer,scenario,"passed",data.width,data.height);
}

for (const viewer of ["maplibre","leaflet","openlayers"]) {
  await page.cdp("Page.addScriptToEvaluateOnNewDocument",{source:`window.__qa={errors:[],unhandled:[]};addEventListener('error',e=>{if(e.message)window.__qa.errors.push(e.message)});addEventListener('unhandledrejection',e=>window.__qa.unhandled.push(String(e.reason)));`});
  await page.goto(`http://127.0.0.1:18381/${viewer}?dataset=eox_cloudless.tif&mode=single&opacity=1&bidx=1&bidx=2&bidx=3&zoom=1&center=0,0`);
  await record(viewer,"initial-rgb");
  console.log(await page.snapshot());
  await page.screenshot({path:`${out}/${viewer}-current.png`});
  await page.evaluate(()=>performance.clearResourceTimings());
  await page.selectOption("#format","webp");await page.selectOption("#tilesize","512");
  await page.click("button[type=submit]");
  await record(viewer,"webp-512");
  assert.equal(results.at(-1).width,512);
  assert.equal(JSON.parse(new URL(results.at(-1).url).searchParams.get("extension_fields"))["raster:tile"].lossless,true);
  await page.evaluate(()=>performance.clearResourceTimings());
  await page.fill("#expression","b1+b2");await page.selectOption("#stretch","linear");await page.fill("#rescale","0,510");
  await page.click("button[type=submit]");
  await record(viewer,"expression-plus",{expression:"b1+b2",method:"linear"});
  assert.ok(results.at(-1).url.includes("%2B"));assert.equal(results.at(-1).expressionDisabled,true);
  for (const method of ["none","minmax","percentile","stddev","histogram_equalization","curve"]) {
    await page.evaluate(()=>performance.clearResourceTimings());
    await page.selectOption("#stretch",method);await page.click("button[type=submit]");
    await record(viewer,`stretch-${method}`,{method});
  }
  await page.cdp("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:false});
  await record(viewer,"390px-layout",{method:"curve"});
  await page.screenshot({path:`${out}/${viewer}-390.png`});
  await page.cdp("Emulation.setDeviceMetricsOverride",{width:320,height:844,deviceScaleFactor:1,mobile:false});
  await record(viewer,"320px-layout",{method:"curve"});
  await page.screenshot({path:`${out}/${viewer}-320.png`});
  await page.cdp("Emulation.clearDeviceMetricsOverride");
}
for(const viewer of ["maplibre","leaflet","openlayers"]) {
 await page.cdp("Page.addScriptToEvaluateOnNewDocument",{source:`window.__qa={errors:[],unhandled:[]};addEventListener("error",e=>{if(e.message)window.__qa.errors.push(e.message)});addEventListener("unhandledrejection",e=>window.__qa.unhandled.push(String(e.reason)));`});
 await page.goto(`http://127.0.0.1:18381/${viewer}?dataset=eox_cloudless.tif&mode=single&opacity=1`);
 await completed({dataset:"eox_cloudless.tif"});
 await page.waitForFunction(()=>rasterReady && (typeof map.getZoom!=="function" || !map._animatingZoom));
 await page.evaluate(()=>performance.clearResourceTimings());
 const dataset="SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif";
 await page.selectOption("#dataset",dataset);
 await page.waitForFunction(()=>typeof map.getZoom==="function"?map.getZoom()>=10:map.getView().getZoom()>=10,undefined,{timeout:30000});
 await page.waitForFunction((file)=>performance.getEntriesByType("resource").filter(e=>e.responseStatus===200 && e.name.includes("/tiles/") && new URL(e.name).searchParams.get("dataset")===file && Number(new URL(e.name).pathname.split("/")[3])>=10).length>=3,dataset,{timeout:30000});
 await record(viewer,"switch-uint16-utm",{dataset});
 await page.screenshot({path:`${out}/${viewer}-uint16.png`});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(r)));
 await page.mouse.move(850,500);await page.mouse.wheel(0,-100);
 await record(viewer,"wheel-zoom",{dataset});
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(r)));
 await page.mouse.move(850,500);await page.mouse.down();await page.mouse.move(830,505);await page.mouse.up();
 await record(viewer,"drag-pan",{dataset});
 const previous=results.find(r=>r.viewer===viewer && r.scenario==="webp-512");
 const query=new URL(previous.url).searchParams;query.delete("_v");
 await page.goto(`http://127.0.0.1:18381/${viewer}?${query}`);
 await record(viewer,"extension-permalink-restore");
 assert.equal(results.at(-1).width,512);
 assert.deepEqual(await page.evaluate(()=>({format:document.getElementById("format").value,size:document.getElementById("tilesize").value})),{format:"webp",size:"512"});
 await page.goto(`http://127.0.0.1:18381/${viewer}?extension_fields=null`);
 await page.waitForSelector("#style-error",{state:"visible"});
 assert.match(await page.evaluate(()=>document.getElementById("style-error").textContent),/^Invalid extension_fields:/);
 console.log(viewer,"malformed input handled visibly");
}
console.log("extra browser cases passed");
await page.cdp("Page.addScriptToEvaluateOnNewDocument",{source:`window.__qa={errors:[],unhandled:[]};addEventListener("error",e=>{if(e.message)window.__qa.errors.push(e.message)});addEventListener("unhandledrejection",e=>window.__qa.unhandled.push(String(e.reason)));`});
await page.goto("http://127.0.0.1:18381/maplibre?mode=mosaic&center=116.7,38.2&zoom=8&opacity=1&method=minmax");
await record("maplibre","mosaic-first-fixed");
console.log(await page.snapshot());
await page.evaluate(()=>performance.clearResourceTimings());
await page.selectOption("#pixel_selection","highest");await page.selectOption("#stage","after_channels");await page.fill("#rank_channel","1");await page.click("button[type=submit]");
await record("maplibre","mosaic-highest-after-fixed");
assert.equal(JSON.parse(new URL(results.at(-1).url).searchParams.get("extension_fields"))["raster:mosaic"].stage,"after_channels");
await page.screenshot({path:`${out}/maplibre-mosaic-fixed.png`});
console.log("mosaic fixed cases passed");

await page.goto("http://127.0.0.1:18381/leaflet?dataset=eox_cloudless.tif&mode=single&opacity=1");
await page.waitForFunction(()=>rasterReady && cogLayer && !zooming);
const overlap = await page.evaluate(()=>new Promise(resolve=>{
 map.once("zoomstart",()=>{
  const select=document.getElementById("dataset");select.value="SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif";
  select.dispatchEvent(new Event("change",{bubbles:true}));resolve(zooming);
 });
 document.querySelector('a[aria-label="Zoom in"]').click();
}));
assert.equal(overlap,true);
await page.waitForFunction(()=>rasterReady && !zooming && map.getZoom()>=10,undefined,{timeout:30000});
assert.ok(Math.abs((await page.evaluate(()=>map.getCenter().lng))-120.14)<0.05);
await record("leaflet","switch-during-zoom-fixed",{dataset:"SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif"});
await page.screenshot({path:`${out}/leaflet-zoom-switch-fixed.png`});
await page.goto("http://127.0.0.1:18381/openlayers?dataset=SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif&method=minmax&opacity=1");
await page.waitForFunction(()=>rasterReady && !map.getView().getAnimating());
await page.evaluate(()=>new Promise(resolve=>{map.once("rendercomplete",()=>resolve());map.render();}));
await page.screenshot({path:`${out}/openlayers-uint16-settled.png`});
await fs.writeFile(`${out}/browser-environment.json`,JSON.stringify(await page.evaluate(()=>({userAgent:navigator.userAgent,hardwareConcurrency:navigator.hardwareConcurrency,devicePixelRatio,viewport:[innerWidth,innerHeight]})),null,2));
console.log("FINAL browser states",results.length);
console.log("Keeping the layout acceptance page until screenshots are visually inspected");
