import pathlib,json,gzip,tarfile,hashlib
R=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/zhang/code/async-geotiff-rs')
dest=repo/'docs/benchmarks/titiler-comparison'
s=json.loads((R/'summary.json').read_text());steady=json.loads((R/'steady-summary.json').read_text());profile=json.loads((R/'profile-summary.json').read_text())
s['d1_steady_recheck']=steady;s['diagnostic_stage_profile']=profile
(R/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(dest/'warm-optimization-20260930-results.json').write_text((R/'summary.json').read_text())
raw=[]
for name,p in [('original_difference_recheck',R/'recheck-raw.json'),('new_optimization',R/'steady/recheck-raw.json')]:
 for row in json.loads(p.read_text()):raw.append(dict(row,experiment=name))
assert len(raw)==2640 and all(r['status']==200 for r in raw)
assert len({r['png_sha256'] for r in raw})==1
with (dest/'warm-optimization-20260930-d1-steady.jsonl.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(''.join(json.dumps(x)+'\n' for x in raw).encode())
section=['## D1 热请求后续优化（2026-09-30）','',
'本节是上述首轮优化之后的追加验证。before 为已包含 SDK 预热与完整波段借用的版本，after 仅追加 `src/warp/reproject.rs` 的原生整数 nearest 采样。此前的 +0.28 ms 记录保留为历史结果，不能当作当前状态。','',
'### 复现与原因','',
'先用首轮优化前／后的原始二进制重新交替测试 30 轮，每个进程连续请求同一 D1 瓦片 22 次。二次请求为 3.090 → 2.625 ms（-15.1%），其按进程配对 bootstrap 95% 区间为 -42.7%～+61.9%；第 3～22 次的连续热请求为 1.731 → 1.771 ms（+2.4%），按每进程中位数 bootstrap 区间为 -0.7%～+5.2%。原 +15% 没有稳定复现，不能归因于首轮补丁；新进程二次请求波动尤其大。本机未隔离，这些区间只描述本轮样本。','',
'当前 D1 为 UInt16、EPSG:32651、NoData=0，走跨投影选定波段的标量采样。独立阶段日志显示，热请求主要成本在 fused CPU，而非读取。原路径逐波段构造源尺寸 F64 与数值掩码，再构造 F64 目标并转回原类型；nearest 只需要读取一个原生像素，这些中间数据不必要。','',
'现在仅对选定波段的 UInt8/UInt16 nearest 使用借用数组直接采样，在采样点检查源掩码和该波段 NoData，并保留共同输出有效性。沿用原坐标网格、半像素边界、夹取与舍入；无效值填充仍按原类型转换。浮点、宽整数及插值核继续原路径；没有新增依赖、缓存或 unsafe，也未更改渲染量化、PNG 编码和容量限制。','',
'### D1 连续热请求验证','',
'再用首轮优化版本和本次版本交替测试 30 轮，每版本 660 请求，均为相同中心瓦片 z18/218555/99045。每进程第 1 次为首次，第 2 次为二次，第 3～22 次为连续热请求。计时期间没有编译或测试负载。','',
'| 指标 | before → after | 变化 |','|---|---:|---:|',
'| 二次请求，30 个样本／版本 | 3.519 → 2.973 ms | -15.5% |',
'| 连续热请求，600 个样本／版本 | 1.677 → 1.199 ms | -28.5% |',
'| 连续热请求，每进程中位数再取中位数 | 1.682 → 1.199 ms | -28.7% |','',
'按 30 个进程配对整体重采样（10,000 次，seed=244），连续热请求的每进程中位数变化 95% 区间为 **-30.0%～-27.5%**；二次请求区间为 -58.5%～+64.8%，不据此声称二次请求已稳定改善。连续请求并非 600 个独立进程样本。','',
'perf-tracing 独立诊断各 10 进程、100 个热请求，未混入正式 HTTP 计时：','',
'| 阶段中位数 | before → after（ms） |','|---|---:|',
f"| 规划 | {profile['before']['plan_ms']:.3f} → {profile['after']['plan_ms']:.3f} |",
f"| 读取 | {profile['before']['read_window_ms']:.3f} → {profile['after']['read_window_ms']:.3f} |",
f"| fused CPU（warp + render，含调度） | {profile['before']['fused_cpu_ms']:.3f} → {profile['after']['fused_cpu_ms']:.3f} |",'',
'CPU 阶段下降约 34.1%，规划与读取基本持平，与删去整数 nearest 中间转换的预期一致。该阶段不进一步分离 warp 与 PNG 编码，不能把全段收益解释为单个子步骤的纯 CPU 时间。','',
'### 五份数据的完整配对回归','',
'仍按既有 10 对单瓦片、每级别 5 对浏览器 16 瓦片、5 对 32 并发批次运行，共 6600 次请求（每版本 3300）。版本按轮次／数据交替，默认 features release、关闭 perf-tracing，原数据、波段、范围、nearest 和 PNG256 不变。没有重新测试 TiTiler，下表只比较两版 Rust；不得把跨轮绝对耗时直接用于版本归因。','']
for scenario,label in [('single','单瓦片'),('viewport','浏览器 16 瓦片'),('burst32','32 并发批次')]:
 section+=['#### '+label,'','| 数据 | z | 首次 before → after（ms） | 变化 | 二次 before → after（ms） | 变化 |','|---|---:|---:|---:|---:|---:|']
 rows=s['rows']
 for dataset,z in sorted({(r['dataset'],r['zoom']) for r in rows if r['scenario']==scenario}):
  a=next(r for r in rows if (r['scenario'],r['dataset'],r['zoom'],r['phase'])==(scenario,dataset,z,'first'));b=next(r for r in rows if (r['scenario'],r['dataset'],r['zoom'],r['phase'])==(scenario,dataset,z,'second'))
  section.append(f"| {dataset} | {z} | {a['before_ms']:.2f} → {a['after_ms']:.2f} | {a['change_percent']:+.1f}% | {b['before_ms']:.2f} → {b['after_ms']:.2f} | {b['change_percent']:+.1f}% |")
 section+=['']
section+=['### 校验、review 与剩余问题','',
'6600/6600 请求有效；所有单瓦片与并发批次的匹配坐标像素哈希一致，中心 PNG 字节完全一致，响应大小不变。浏览器逐张验证 256²、可见、成功，客户端缓存命中为零。追加两组 D1 复测共 2640/2640 请求成功，所有 PNG 哈希与原版本一致。','',
'新增对照测试将原生 selected-nearest 和 F64 参考路径比较，覆盖 UInt8/UInt16、同／跨投影、部分越界、掩码、有无 NoData、非整数／负／NaN／Infinity NoData、子集／重复波段和非连续布局。all-features 库 291 通过、2 忽略；集成及 serve 共 56 通过，总计 **347 通过**。严格 Clippy、fmt、diff 检查通过。按 rust-skills 检查借用、边界验证、内部 expect 不变量、并行掩码合并和中间分配，未发现需要修复的新问题。','',
'D1 连续热请求的固定开销已降低；首轮 +0.28 ms 无法稳定复现。仍不能声称所有热场景全面改善：本轮 D3 浏览器二次 +6.0%／+7.1%，D5 z15 二次 +8.3%；D4/D5 单瓦片二次 +4.4%／+2.4%（约 0.02～0.04 ms）。这些行只有 5 或 10 对样本，未建立因果关系或统计显著性，不把它们当作已确认的新代码退化。MAP-244 保持打开，继续跟踪浮点／插值路径及端到端剩余差距；本次修复并不覆盖这些路径。','',
'结果：[warm-optimization-20260930-results.json](benchmarks/titiler-comparison/warm-optimization-20260930-results.json)；[完整配对记录](benchmarks/titiler-comparison/warm-optimization-20260930-raw.jsonl.gz)；[D1 复测逐请求记录](benchmarks/titiler-comparison/warm-optimization-20260930-d1-steady.jsonl.gz)；[复现脚本、补丁及验证日志](benchmarks/titiler-comparison/warm-optimization-20260930-procedure.tar.gz)。源码尚未提交。','']
p=repo/'docs/raster-style-performance-optimization.md';p.write_text(p.read_text()+'\n'+'\n'.join(section))
p=repo/'docs/performance-comparison-titiler.md';p.write_text(p.read_text().replace('随后两处性能改动及交替配对复测','随后多轮性能优化及交替配对复测'))
(R/'REPRODUCE.md').write_text('''# D1 native nearest follow-up

Before binary: previous optimization (optimization-20260930-procedure.tar.gz).
After: before + continuation.patch. combined.patch is against base HEAD.
meta.json records the executable and source SHA-256 values. Binaries and the
five original COG datasets are excluded. No dependencies or benchmarks are
installed by these scripts.

Use the original data directory, TiTiler Python environment and Playwright setup.
Build the temporary example titiler_comparison_bench.rs with default features:
    cargo build --release --example titiler_comparison_bench
Save binaries as before-server / after-server in this procedure directory.
Keep the original serve binary as the shared /data Range origin. Remove the
temporary example after building. Do not compile during measurement.

With ports 18980 and 18981 unused, run using the original TiTiler .venv Python:
    python paired_bench.py > paired-progress.log 2>&1
    python steady.py > steady.log 2>&1
    python steady_summary.py
    python summarize.py

paired_bench.py requires fresh paired/before and paired/after output directories.
steady.py uses this directory's binary pair and stores results under steady/.
recheck.py uses the two historical binaries at /private/tmp/raster-style-opt6
to reassess the original +15% observation. Adjust paths if reconstructing.
steady_summary.py expects both diagnostic runs and resamples 30 whole process
pairs, rather than treating the 600 repeated warm responses as independent.
All startup is excluded; OS cache is retained; machine is not isolated.

For independent stage profiling only, build each version with perf-tracing,
save profile-before-server and profile-after-server, and run profile_stages.py.
Profile logs exclude each process's first request. Do not compare logged profile
latency as if it were the uninstrumented HTTP benchmark.

prepare_results.py and summarize.py write structured results into the repo's
documentation directory at the original absolute path. publish.py appends the
report and packages artifacts; it is not idempotent. Preserve existing results
before rerunning publication.
''')
with tarfile.open(dest/'warm-optimization-20260930-procedure.tar.gz','w:gz') as t:
 for name in ['REPRODUCE.md','meta.json','continuation.patch','combined.patch','datasets.json','recheck.py','steady.py','steady_summary.py','steady-summary.json','profile_stages.py','profile-summary.json','paired_bench.py','paired_harness.py','paired_comparison.py','browser.cjs','prepare_results.py','summarize.py','publish.py','titiler_comparison_bench.rs','tests.log','clippy.log','build.log','profile-build.log','paired-progress.log','recheck.log','steady.log','profile-progress.log','profile-before/rust-server.log','profile-after/rust-server.log']:
  t.add(R/name,arcname=name)
print('Published results, report and reproduction archive')
