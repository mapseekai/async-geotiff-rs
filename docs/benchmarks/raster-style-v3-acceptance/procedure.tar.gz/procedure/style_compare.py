"""Paired hot-style requests for real U16/U8 datasets; use compare.py servers."""
import concurrent.futures as futures
import hashlib
import http.client
import json
import statistics
import time
from urllib.parse import parse_qsl, urlencode
import compare as bench

OUT = bench.OUT
PROFILES = ['minmax','percentile','stddev','histogram_equalization','expression-plus','webp-512']

def request_path(label, item, profile):
    base, query = bench.path(label,item,item['tile']).split('?')
    params = [(k,v) for k,v in parse_qsl(query) if k not in ['method','rescale']]
    if profile == 'expression-plus':
        params = [(k,v) for k,v in params if k not in ['bidx','type']]
        bounds = [list(map(float, value.split(','))) for value in item['rescale'][:2]]
        rescale = f"{sum(b[0] for b in bounds)},{sum(b[1] for b in bounds)}"
        params += [('type','gray'),('expression','b1+b2'),('method','linear'),('rescale',rescale)]
    elif profile == 'webp-512':
        params += [('method','linear')] + [('rescale',v) for v in item['rescale']]
        params = [(k,v) for k,v in params if k not in ['format','tilesize','extension_fields']]
        if label == 'baseline': params += [('format','webp'),('tilesize','512'),('lossless','true')]
        else: params += [('extension_fields','{"raster:tile":{"format":"webp","tilesize":512,"lossless":true}}')]
        base = base.removesuffix('.png') + '.webp'
    else:
        params += [('method',profile)]
        if profile == 'percentile': params += [('percentiles','2,98')]
        if profile == 'stddev': params += [('stddev','2')]
    return base+'?'+urlencode(params)

def run(label, path):
    conn=http.client.HTTPConnection('127.0.0.1',bench.PORTS[label],timeout=40)
    try:
        started=time.perf_counter();conn.request('GET',path);response=conn.getresponse();body=response.read();first_ms=(time.perf_counter()-started)*1000
        assert response.status==200,(response.status,body[:300])
        expected=hashlib.sha256(body).hexdigest()
    finally:conn.close()
    def worker(_):
        conn=http.client.HTTPConnection('127.0.0.1',bench.PORTS[label],timeout=40);latencies=[]
        try:
            for _ in range(6):
                start=time.perf_counter();conn.request('GET',path);r=conn.getresponse();b=r.read();latencies.append((time.perf_counter()-start)*1000)
                assert r.status==200 and hashlib.sha256(b).hexdigest()==expected
        finally:conn.close()
        return latencies
    with futures.ThreadPoolExecutor(max_workers=4) as pool:
        start=time.perf_counter();latencies=[x for row in pool.map(worker,range(4)) for x in row];wall=(time.perf_counter()-start)*1000
    return dict(first_ms=first_ms,warm_wall_ms=wall,latencies_ms=latencies,sha256=expected,bytes=len(body))

def main():
    assert not (OUT/'style-raw.jsonl').exists(),'Do not overwrite or silently resume an incomplete run'
    rows=[]
    for d in [0,2]:
        for round_id in range(6):
            for label in (['baseline','current'] if round_id%2==0 else ['current','baseline']):
                with bench.server(label):
                    for profile in PROFILES:
                        row=dict(dataset=d,round=round_id,label=label,profile=profile,**run(label,request_path(label,bench.ITEMS[d],profile)))
                        rows.append(row)
                        with (OUT/'style-raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print('style pair',d,round_id,'passed',flush=True)
    result=[]
    for d in [0,2]:
        for profile in PROFILES:
            pairs={i:{r['label']:r for r in rows if r['dataset']==d and r['profile']==profile and r['round']==i} for i in range(6)}
            for p in pairs.values():assert p['baseline']['sha256']==p['current']['sha256'],(d,profile)
            ratios=[p['current']['warm_wall_ms']/p['baseline']['warm_wall_ms'] for p in pairs.values()]
            result.append(dict(dataset=d,profile=profile,pairs=6,requests_per_pair_per_variant=25,baseline_ms=statistics.median(p['baseline']['warm_wall_ms'] for p in pairs.values()),current_ms=statistics.median(p['current']['warm_wall_ms'] for p in pairs.values()),paired_change_percent=(statistics.median(ratios)-1)*100))
    (OUT/'style-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
