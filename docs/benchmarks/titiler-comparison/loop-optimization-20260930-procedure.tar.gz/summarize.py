import pathlib,json,statistics,random
R=pathlib.Path(__file__).resolve().parent
med=statistics.median

def contrast(a,b):
 assert len(a)==len(b) and len(a)>1
 rng=random.Random(244);samples=[]
 for _ in range(10000):
  ids=[rng.randrange(len(a)) for _ in a]
  samples.append((med([b[i] for i in ids])/med([a[i] for i in ids])-1)*100)
 samples.sort()
 return dict(before=med(a),after=med(b),change_pct=(med(b)/med(a)-1)*100,paired_bootstrap95_pct=[samples[249],samples[9749]])

def summarize(cpu_path,http_path):
 cpu=json.loads(cpu_path.read_text());http=json.loads(http_path.read_text());out={'cpu':[],'encode_only':[],'http':[]}
 for size in [256,1024]:
  for dtype in ['u8','u16','f64']:
   data={v:sorted([x for x in cpu if x.get('size')==size and x.get('dtype')==dtype and x['version']==v and x['scenario']=='render_encode'],key=lambda x:x['round']) for v in ['before','after']}
   c=contrast([x['after_us'] for x in data['before']],[x['after_us'] for x in data['after']]);c.update(size=size,dtype=dtype,unit='us',legacy_before=med(x['before_us'] for x in data['before']),legacy_after=med(x['before_us'] for x in data['after']))
   # Each process measures current and its linked legacy control; resample processes, not loop iterations.
   ratios=[x['after_us']/x['before_us'] for x in data['after']];c['after_vs_legacy_ratio_median_pct']=(med(ratios)-1)*100
   rng=random.Random(244);rs=sorted((med(rng.choices(ratios,k=len(ratios)))-1)*100 for _ in range(10000));c['after_vs_legacy_ratio_bootstrap95_pct']=[rs[249],rs[9749]]
   out['cpu'].append(c)
 for size in [256,1024]:
  for dtype in ['u8','u16','f64']:
   data={v:sorted([x for x in cpu if x.get('size')==size and x.get('dtype')==dtype and x['version']==v and x['scenario']=='encode_only'],key=lambda x:x['round']) for v in ['before','after']}
   c=contrast([x['after_us'] for x in data['before']],[x['after_us'] for x in data['after']]);c.update(size=size,dtype=dtype,unit='us',legacy_before=med(x['before_us'] for x in data['before']),legacy_after=med(x['before_us'] for x in data['after']))
   out['encode_only'].append(c)
 for f in dict.fromkeys(x['file'] for x in http):
  for kind in ['single','viewport']:
   by={}
   for v in ['legacy','before','after']:
    by[v]=[]
    for n in range(10):
     rows=[x for x in http if x['file']==f and x['scenario']==kind and x['version']==v and x['round']==n and (x.get('index',-1)>=2 if kind=='single' else x['phase']=='second')]
     by[v].append(med(x['elapsed_ms' if kind=='single' else 'load_ms'] for x in rows))
   c=contrast(by['before'],by['after']);c.update(file=f,scenario='steady_single' if kind=='single' else 'warm_viewport',unit='ms',legacy=med(by['legacy']),after_vs_legacy=contrast(by['legacy'],by['after']))
   out['http'].append(c)
 singles=[x for x in http if x['scenario']=='single'];viewports=[x for x in http if x['scenario']=='viewport']
 assert len(singles)==1650 and len(viewports)==300
 assert all(x['status']==200 and x['width']==x['height']==256 and x['visible_fraction']>0 and 'error' not in x for x in singles)
 assert all(x['count']==x['requests']==x['network_requests']==x['visible_tiles']==16 and x['cache_hits']==x['errors']==0 and x['browser_cache_disabled'] and all(t['status']==200 and t['width']==t['height']==256 and t['visible_fraction']>0 for t in x['tiles']) for x in viewports)
 for f in dict.fromkeys(x['file'] for x in singles):
  assert len({x['pixel_sha256'] for x in singles if x['file']==f and x['version'] in ['before','after']})==1
 out['validation']={'http_requests':6450,'single_requests':1650,'viewport_requests':4800,'rounds':10,'versions':3,'all_http_valid':True,'single_before_after_pixels_exact':True,'browser_cache_hits':0,'cpu_reference_max_byte_error':max(x['rgba_max_error'] for x in cpu if x['scenario']=='render_encode')}
 return out
if __name__=='__main__':
 import sys
 out=summarize(R/'cpu-pairs.json',pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else R/'final-http/http-pairs.json')
 (R/'results.json').write_text(json.dumps(out,indent=2)+'\n')
 for x in out['cpu']:print('CPU',x)
 for x in out['http']:print(x['scenario'],x['file'],x)
