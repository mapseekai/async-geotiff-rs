import pathlib,json,hashlib,subprocess,datetime
R=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/zhang/code/async-geotiff-rs')
old=json.loads(pathlib.Path('/private/tmp/raster-style-opt6/meta.json').read_text())
meta={
 'measured_at':datetime.datetime.now().astimezone().isoformat(),
 'base_head':old['base_head'],
 'before':'Previous optimization patch: SDK startup warmup + native complete-band borrowing',
 'after':'Before + native selected nearest sampling (continuation.patch)',
 'before_binary_sha256':hashlib.sha256((R/'before-server').read_bytes()).hexdigest(),
 'after_binary_sha256':hashlib.sha256((R/'after-server').read_bytes()).hexdigest(),
 'features':'default, perf-tracing disabled for HTTP benchmark; stage profiling separate',
 'procedure':old['procedure'],
 'limitations':old['limitations'],
 'source_hashes':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in ['src/warp/reproject.rs','src/style/raster.rs','examples/serve/server.rs','Cargo.toml','Cargo.lock']},
 'before_warp_sha256':hashlib.sha256((R/'reproject-before.rs').read_bytes()).hexdigest(),
 'origin_binary_sha256':hashlib.sha256((repo/'target/release/examples/serve').read_bytes()).hexdigest(),
}
assert meta['before_binary_sha256']==old['after_binary_sha256']
(R/'meta.json').write_text(json.dumps(meta,indent=2)+'\n')
(R/'continuation.patch').write_bytes(subprocess.check_output(['rtk','proxy','git','diff','--','src/warp/reproject.rs'],cwd=repo))
(R/'combined.patch').write_bytes(subprocess.check_output(['rtk','proxy','git','diff','--','src/warp/reproject.rs','src/style/raster.rs','examples/serve/server.rs'],cwd=repo))
# Reuse the already validated aggregation and image checks without rewriting prior results.
s=pathlib.Path('/private/tmp/raster-style-opt6/summarize.py').read_text()
s=s[:s.index('doc=[')]
s=s.replace('optimization-20260930-', 'warm-optimization-20260930-')
(R/'summarize.py').write_text(s)
