"""Final CSS-only release versus the immutable measured Q3 binary: byte parity."""
from collections import Counter
import hashlib
import json
import compare as bench
import style_compare as styles

OUT=bench.OUT

def main():
    bench.PORTS['final']=18382
    (OUT/'final').mkdir(exist_ok=True)
    data=OUT/'final/data'
    if not data.exists():data.symlink_to(bench.ROOT/'data',target_is_directory=True)
    variants={};count=0
    for label in ['current','final']:
        records=[]
        with bench.server(label):
            for d,item in enumerate(bench.ITEMS):
                batch=bench.batch(label,[bench.path(label,item,c) for c in bench.coordinates(item)],6)
                count+=len(batch['responses'])
                signatures=Counter((r['path'],r['sha256'],r['bytes']) for r in batch['responses'])
                records.append(dict(dataset=d,scenario='viewport32',responses=[list(k)+[v] for k,v in sorted(signatures.items())]))
            for d in [0,2]:
                for profile in styles.PROFILES:
                    result=styles.run(label,styles.request_path(label,bench.ITEMS[d],profile));count+=25
                    records.append(dict(dataset=d,scenario=profile,sha256=result['sha256'],bytes=result['bytes']))
        variants[label]=records
    assert variants['current']==variants['final']
    report=dict(purpose='Functional byte parity after CSS-only embedding changes; not a replacement performance measurement',successful_requests=count,binary_sha256={label:hashlib.sha256((OUT/f'serve-{label}').read_bytes()).hexdigest() for label in ['current','final']},identical=True,variants=variants)
    (OUT/'post-layout-parity.json').write_text(json.dumps(report,indent=2)+'\n');print('Final/measured binaries:',count,'requests passed with byte-identical PNG/WebP')

if __name__=='__main__':main()
