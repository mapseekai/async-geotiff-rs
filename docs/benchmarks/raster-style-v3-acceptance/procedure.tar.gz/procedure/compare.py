"""Paired process-cold/warm HTTP acceptance for Raster Style SDK migration."""
import concurrent.futures as futures
import contextlib
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import platform
import random
import socket
import statistics
import struct
import subprocess
import threading
import time
from urllib.parse import urlencode

ROOT = Path('/Users/zhang/code/async-geotiff-rs')
OUT = Path('/tmp/raster-q3-acceptance-20261019')
ITEMS = json.loads(Path('/Users/zhang/code/titiler-vs-async-geotiff-bench/large-cog-comparison/datasets.json').read_text())
PORTS = {'baseline':18380, 'current':18381}
RECORDS = []
URL = 'https://mapseekai.github.io/raster-style/extensions/raster/tile/v1.0.0/schema.json'

def path(label, item, coord):
    z,x,y = coord
    params = [('version','2.0' if label=='baseline' else '3.0'),('type','rgb'),('dataset',item['file']),('method','linear')]
    params += [('bidx',str(b)) for b in item['indexes']] + [('rescale',v) for v in item['rescale']]
    params += [('resampling','nearest'),('reproject','nearest')]
    if label=='baseline': params += [('tilesize','256'),('format','png')]
    else: params += [('extensions',json.dumps([URL],separators=(',',':'))),('extension_fields','{"raster:tile":{"format":"png","tilesize":256}}')]
    return f'/tiles/WebMercatorQuad/{z}/{x}/{y}.png?'+urlencode(params)

def coordinates(item):
    z = min(item['viewport_zoom']+1,item['maxzoom']);lon,lat=item['center'];n=2**z
    x=int((lon+180)/360*n); y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n)
    return [(z,x+dx,y+dy) for dy in range(-1,3) for dx in range(-3,5)]

@contextlib.contextmanager
def server(label):
    port=PORTS[label]
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.1): raise RuntimeError(f'port {port} occupied')
    except ConnectionRefusedError: pass
    env={k:v for k,v in os.environ.items() if not k.startswith('ASYNC_GEOTIFF_')}
    env.update(RUST_LOG='off',ASYNC_GEOTIFF_BIND=f'127.0.0.1:{port}',ASYNC_GEOTIFF_BLOCK_CACHE_MB='256',ASYNC_GEOTIFF_MAX_TILE_TASKS='4',ASYNC_GEOTIFF_MAX_DECODE_TASKS='4',ASYNC_GEOTIFF_PREFETCH_RING='0')
    with (OUT/f'server-{label}.log').open('ab') as log:
        process=subprocess.Popen([str(OUT/f'serve-{label}')],cwd=OUT/label,env=env,stdout=log,stderr=log)
        try:
            for _ in range(1000):
                if process.poll() is not None: raise RuntimeError(f'{label} exited: '+(OUT/f'server-{label}.log').read_text()[-1500:])
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.05): break
                except OSError: time.sleep(.01)
            else: raise TimeoutError('startup')
            yield process
        finally:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired: process.kill();process.wait()

def batch(label, paths, concurrency):
    count=min(concurrency,len(paths));barrier=threading.Barrier(count+1)
    def worker(index):
        conn=http.client.HTTPConnection('127.0.0.1',PORTS[label],timeout=40);rows=[]
        try:
            barrier.wait(timeout=10)
            for url in paths[index::count]:
                t=time.perf_counter();conn.request('GET',url,headers={'Cache-Control':'no-cache'});r=conn.getresponse();body=r.read();elapsed=(time.perf_counter()-t)*1000
                if r.status!=200:raise RuntimeError(f'{r.status}: {body[:400]}')
                assert body[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',body[16:24])==(256,256)
                rows.append({'url':url,'path':url.split('?')[0],'ms':elapsed,'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)})
        finally:conn.close()
        return rows
    with futures.ThreadPoolExecutor(max_workers=count) as pool:
        jobs=[pool.submit(worker,i) for i in range(count)];started=time.perf_counter();barrier.wait(timeout=10)
        rows=[r for job in jobs for r in job.result()];elapsed=(time.perf_counter()-started)*1000
    return {'wall_ms':elapsed,'rps':len(rows)/(elapsed/1000),'latencies_ms':[r['ms'] for r in rows],'responses':rows}

def emit(row):
    RECORDS.append(row)
    with (OUT/'raw.jsonl').open('a') as f:f.write(json.dumps(row,separators=(',',':'))+'\n')

def paired():
    for number,item in enumerate(ITEMS):
        for round_id in range(6):
            order=['baseline','current'] if round_id%2==0 else ['current','baseline']
            for label in order:
                with server(label):
                    tile=path(label,item,item['tile']);view=[path(label,item,c) for c in coordinates(item)]
                    for name,paths,c in [('cold_single',[tile],1),('warm_single',[tile]*64,1),('viewport_first',view[:16],6),('viewport_warm',view[:16],6),('burst32',view*4,32)]:
                        result=batch(label,paths,c);emit(dict(dataset=number,label=label,round=round_id,scenario=name,**result))
            print('pair',number,round_id,'passed',flush=True)

def stress():
    for round_id in range(2):
        for label in (['baseline','current'] if round_id==0 else ['current','baseline']):
            with server(label) as process:
                paths=[path(label,item,c) for item in ITEMS for c in coordinates(item)[:8]]
                warm=batch(label,paths,16)
                expected={r['url']:r['sha256'] for r in warm['responses']}
                samples=[];stop=threading.Event();barrier=threading.Barrier(33)
                def worker(index):
                    conn=http.client.HTTPConnection('127.0.0.1',PORTS[label],timeout=40)
                    latencies=[]
                    try:
                        conn.connect();barrier.wait(timeout=10)
                        while time.monotonic()-started<20:
                            url=paths[(index+len(latencies))%len(paths)]
                            begin=time.perf_counter();conn.request('GET',url);r=conn.getresponse();body=r.read();latencies.append((time.perf_counter()-begin)*1000)
                            assert r.status==200 and hashlib.sha256(body).hexdigest()==expected[url]
                    finally:conn.close()
                    return latencies
                def monitor():
                    while not stop.is_set():
                        row=subprocess.check_output(['ps','-o','rss=,%cpu=','-p',str(process.pid)],text=True).split()
                        if row:samples.append({'seconds':time.monotonic()-started,'rss_bytes':int(row[0])*1024,'cpu_percent':float(row[1])})
                        stop.wait(.5)
                with futures.ThreadPoolExecutor(max_workers=32) as pool:
                    jobs=[pool.submit(worker,i) for i in range(32)]
                    started=time.monotonic();barrier.wait(timeout=10)
                    thread=threading.Thread(target=monitor);thread.start()
                    try:latencies=[x for job in jobs for x in job.result()]
                    finally:stop.set();thread.join()
                elapsed=time.monotonic()-started;count=len(latencies)
                emit(dict(scenario='stress32',round=round_id,label=label,count=count,seconds=elapsed,rps=count/elapsed,latencies_ms=latencies,resources=samples,transport='32 persistent HTTP/1.1 connections'))
                print('stress',round_id,label,count,'requests passed',flush=True)

def summarize():
    rows=[json.loads(s) for s in (OUT/'raw.jsonl').read_text().splitlines()]
    summary=[];random.seed(20261019)
    for d in range(len(ITEMS)):
        for scenario in ['cold_single','warm_single','viewport_first','viewport_warm','burst32']:
            pair={}
            for r in rows:
                if r.get('dataset')==d and r['scenario']==scenario:pair.setdefault(r['round'],{})[r['label']]=r
            ratios=[]
            for p in pair.values():
                assert {(r['path'],r['sha256'],r['bytes']) for r in p['baseline']['responses']}=={(r['path'],r['sha256'],r['bytes']) for r in p['current']['responses']},(d,scenario)
                ratios.append(p['current']['wall_ms']/p['baseline']['wall_ms'])
            bootstrap=sorted(statistics.median(random.choices(ratios,k=len(ratios))) for _ in range(5000))
            summary.append(dict(dataset=d,file=ITEMS[d]['file'],scenario=scenario,baseline_ms=statistics.median(p['baseline']['wall_ms'] for p in pair.values()),current_ms=statistics.median(p['current']['wall_ms'] for p in pair.values()),paired_change_percent=(statistics.median(ratios)-1)*100,paired_bootstrap_95_percent=[(bootstrap[i]-1)*100 for i in [124,4874]],pairs=len(pair)))
    report={'baseline':'5d4f6554ddb0bd0998acf954f8924f8be502a6e2','current':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','--version'],text=True).strip(),'logical_cpus':os.cpu_count(),'release_features':'default + webp','block_cache_mb':256,'cpu_jobs':4,'prefetch_ring':0,'disk_cache':'not purged; process-cold only','datasets':[{**item,'current_size':(ROOT/'data'/item['file']).stat().st_size} for item in ITEMS],'current_source_patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--','examples/serve.rs','examples/leaflet.html','tests/viewer_bootstrap.cjs'],cwd=ROOT)).hexdigest(),'binary_sha256':{l:hashlib.sha256((OUT/f'serve-{l}').read_bytes()).hexdigest() for l in ['baseline','current']},'paired':summary,'stress':[{k:v for k,v in r.items() if k!='latencies_ms'}|{'p95_ms':sorted(r['latencies_ms'])[int(len(r['latencies_ms'])*.95)]} for r in rows if r['scenario']=='stress32'],'pixel_identity':'all corresponding encoded PNG SHA-256 and dimensions match'}
    (OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    for r in summary:print(r['dataset'],r['scenario'],round(r['paired_change_percent'],1),[round(x,1) for x in r['paired_bootstrap_95_percent']],flush=True)

if __name__=='__main__':
    if not (OUT/'raw.jsonl').exists():paired();stress()
    summarize()
