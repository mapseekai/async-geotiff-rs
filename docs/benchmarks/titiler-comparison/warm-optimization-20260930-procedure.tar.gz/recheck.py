import sys,json,pathlib,os,socket,subprocess,time,hashlib,statistics
sys.path.insert(0,'/private/tmp/raster-style-opt6')
import paired_harness as h
R=pathlib.Path(__file__).resolve().parent
item=json.loads(pathlib.Path('/private/tmp/raster-style-opt6/datasets.json').read_text())[0]
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2): raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError: pass
env=os.environ.copy()
for k in list(env):
 if k.startswith('ASYNC_GEOTIFF_'):env.pop(k)
env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
rows=[]
with (R/'origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   if origin.poll() is not None:raise RuntimeError('origin exited')
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  for n in range(30):
   for label in (['before','after'] if n%2==0 else ['after','before']):
    h.ROOT=pathlib.Path('/private/tmp/raster-style-opt6')
    # server() selects ROOT/rust-server; each run uses its own binary directory.
    h.ROOT=R/label;h.ROOT.mkdir(exist_ok=True)
    (h.ROOT/'rust-server').write_bytes(pathlib.Path(f'/private/tmp/raster-style-opt6/{label}-server').read_bytes())
    (h.ROOT/'rust-server').chmod(0o755)
    with h.server('rust',h.ROOT) as (port,startup):
     for i in range(22):
      q=h.request(port,h.tile_path('rust',item,item['tile']));body=q.pop('body')
      assert q['status']==200,q
      q.update(version=label,round=n,index=i,png_sha256=hashlib.sha256(body).hexdigest())
      rows.append(q)
    print(n,label,round(rows[-21]['elapsed_ms'],3),flush=True)
 finally:origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
(R/'recheck-raw.json').write_text(json.dumps(rows,indent=2))
for phase,indices in [('second',[1]),('steady',range(2,22))]:
 for label in ['before','after']:
  a=[r['elapsed_ms'] for r in rows if r['version']==label and r['index'] in indices]
  print(phase,label,'n',len(a),'median',statistics.median(a),'mean',statistics.mean(a),flush=True)
assert len({r['png_sha256'] for r in rows})==1
