// Chromium viewport loader: six requests at a time; timings end after image decoding.
const {chromium}=require(require.resolve('@playwright/test',{paths:['/Users/zhang/code/tasklane']}));
const readline=require('node:readline');
(async()=>{
  let browser; try{browser=await chromium.launch({headless:true});}catch{browser=await chromium.launch({headless:true,channel:'chrome'});}
  console.log(JSON.stringify({ready:true,browser:browser.version()}));
  for await (const line of readline.createInterface({input:process.stdin})) {
    let context;
    try {
      const config=JSON.parse(line); context=await browser.newContext(); const page=await context.newPage();
      await page.goto('http://127.0.0.1:18980/datasets');
      const cdp=await context.newCDPSession(page); await cdp.send('Network.enable');
      await cdp.send('Network.setCacheDisabled',{cacheDisabled:config.cache_disabled});
      let requested=new Set(), cached=new Set();
      cdp.on('Network.requestWillBeSent',e=>{if(config.urls.includes(e.request.url))requested.add(e.requestId);});
      cdp.on('Network.requestServedFromCache',e=>cached.add(e.requestId));
      cdp.on('Network.responseReceived',e=>{if(e.response.fromDiskCache||e.response.fromPrefetchCache)cached.add(e.requestId);});
      const result={};
      for (const phase of ['first','second']) {
        requested.clear();cached.clear();
        result[phase]=await page.evaluate(async urls=>{
          let next=0;const results=[],bitmaps=[];const started=performance.now();
          async function worker(){while(next<urls.length){const i=next++,url=urls[i],t=performance.now();
            try{const response=await fetch(url);const ttfb=performance.now()-t;const blob=await response.blob();const received=performance.now()-t;
              if(!response.ok){results[i]={url,status:response.status,error:await blob.text(),transfer_ms:received};continue;}
              const bitmap=await createImageBitmap(blob);bitmaps[i]=bitmap;
              results[i]={url,status:response.status,bytes:blob.size,ttfb_ms:ttfb,transfer_ms:received,decode_ms:performance.now()-t-received,width:bitmap.width,height:bitmap.height};
            }catch(e){results[i]={url,status:0,error:String(e)};}}}
          await Promise.all(Array.from({length:6},worker));const load_ms=performance.now()-started;
          for(let i=0;i<bitmaps.length;i++){const b=bitmaps[i];if(!b)continue;
            const canvas=document.createElement('canvas');canvas.width=b.width;canvas.height=b.height;
            const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(b,0,0);
            const rgba=ctx.getImageData(0,0,b.width,b.height).data;let visible=0;
            for(let j=3;j<rgba.length;j+=4)if(rgba[j]>0)visible++;
            results[i].visible_fraction=visible/(b.width*b.height);b.close();}
          return {load_ms,tiles:results,count:results.length,concurrency:6,total_bytes:results.reduce((n,r)=>n+(r.bytes||0),0),
            errors:results.filter(r=>r.status!==200).length,visible_tiles:results.filter(r=>r.visible_fraction>0).length};
        },config.urls);
        await new Promise(r=>setTimeout(r,10));
        result[phase].browser_cache_disabled=config.cache_disabled;
        result[phase].requests=requested.size;
        result[phase].cache_hits=[...requested].filter(id=>cached.has(id)).length;
        result[phase].network_requests=requested.size-result[phase].cache_hits;
      }
      await context.close();context=null;console.log(JSON.stringify(result));
    }catch(e){if(context)await context.close();console.log(JSON.stringify({error:String(e)}));}
  }
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
