import collections, datetime, gzip, hashlib, json, pathlib, statistics, subprocess
from zoneinfo import ZoneInfo
R=pathlib.Path(__file__).resolve().parent
old=json.loads((R/'previous-results.json').read_text())
new=json.loads((R/'results.json').read_text())
key=lambda r:(r['scenario'],r['dataset'],r['zoom'],r['engine'],r['phase'])
previous={key(r):r for r in old['aggregates']}
current={key(r):r for r in new['aggregates']}
comparison=[]
for r in new['aggregates']:
 if r['engine']!='rust': continue
 k=key(r); tk=(*k[:3],'titiler',k[-1]); before=previous[tk]['median_ms']/previous[k]['median_ms']; after=current[tk]['median_ms']/r['median_ms']
 comparison.append(dict(scenario=r['scenario'],dataset=r['dataset'],zoom=r['zoom'],phase=r['phase'],
  previous_rust_ms=previous[k]['median_ms'],current_rust_ms=r['median_ms'],rust_change_percent=(r['median_ms']/previous[k]['median_ms']-1)*100,
  previous_titiler_ms=previous[tk]['median_ms'],current_titiler_ms=current[tk]['median_ms'],titiler_change_percent=(current[tk]['median_ms']/previous[tk]['median_ms']-1)*100,
  previous_titiler_over_rust=before,current_titiler_over_rust=after,ratio_change_percent=(after/before-1)*100))
new['environment'].update(measured_date='2026-09-30',timezone='Asia/Shanghai',rust_working_tree='clean tracked source',raster_style_sdk='0.3.0',raster_style_protocol='2.0',rust_query_additions={'version':'2.0','type':'rgb','method':'linear'},procedure='procedure.tar.gz',source_hashes='source-hashes.json')
new['previous_comparison']={'results':'previous-20260929-results.json','raw':'previous-20260929-raw.jsonl.gz','source_hashes':'previous-20260929-source-hashes.json','rows':comparison,'limitation':'Historical end-to-end comparison, not an isolated Raster Style A/B or a statistical significance test.'}
assert len(comparison)==40
assert new['datasets']==old['datasets']
assert all(new['checks'].values())
assert all(r['current_titiler_over_rust']>1 for r in comparison)
(R/'results.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')
with (R/'raw.jsonl.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z: z.write((R/'raw.jsonl').read_bytes())
for scenario in ['single','viewport','burst32']:
 for phase in ['first','second']:
  rs=[r for r in comparison if r['scenario']==scenario and r['phase']==phase]
  print(scenario,phase,'ratio',min(r['current_titiler_over_rust'] for r in rs),max(r['current_titiler_over_rust'] for r in rs),'Rust median change %',statistics.median(r['rust_change_percent'] for r in rs),'TiTiler median change %',statistics.median(r['titiler_change_percent'] for r in rs))
print('QUALITY',json.dumps(new['center_tile_quality']))
print('COMPARISON',json.dumps(comparison,indent=2))
