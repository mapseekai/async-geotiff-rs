"""D1-only ABBA/BAAB balanced blocks with server/client CPU accounting."""
from collections import Counter
import json
import os
import random
import resource
import statistics
import subprocess
import time
import compare as bench

OUT=bench.OUT

def cpu_seconds(pid):
    value=subprocess.check_output(['ps','-p',str(pid),'-o','time='],text=True).strip()
    total=0.0
    for part in value.split(':'):total=total*60+float(part)
    return total

def self_cpu():
    r=resource.getrusage(resource.RUSAGE_SELF)
    return r.ru_utime+r.ru_stime

def main():
    assert not (OUT/'abba-raw.jsonl').exists()
    random.seed(20261019)
    blocks=[['baseline','current','current','baseline']]*3+[['current','baseline','baseline','current']]*3
    random.shuffle(blocks);rows=[]
    for block,order in enumerate(blocks):
        for position,label in enumerate(order):
            with bench.server(label) as process:
                paths=[bench.path(label,bench.ITEMS[1],c) for c in bench.coordinates(bench.ITEMS[1])]*32
                bench.batch(label,paths,32)
                start_server=cpu_seconds(process.pid);start_client=self_cpu();start=time.perf_counter();load=os.getloadavg()
                data=[bench.batch(label,paths,32) for _ in range(4)]
                wall_ms=(time.perf_counter()-start)*1000
                server_cpu=cpu_seconds(process.pid)-start_server;client_cpu=self_cpu()-start_client
                counts=Counter((r['path'],r['sha256'],r['bytes']) for result in data for r in result['responses'])
                row=dict(block=block,position=position,label=label,order=order,wall_ms=wall_ms,count=4096,server_cpu_seconds=server_cpu,client_cpu_seconds=client_cpu,loadavg=load,batches_ms=[r['wall_ms'] for r in data],responses=[dict(path=k[0],sha256=k[1],bytes=k[2],count=v) for k,v in sorted(counts.items())])
                rows.append(row)
                with (OUT/'abba-raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        print('ABBA block',block,order,'passed',flush=True)
    summary=[]
    for block,order in enumerate(blocks):
        variants={label:[r for r in rows if r['block']==block and r['label']==label] for label in ['baseline','current']}
        assert variants['baseline'][0]['responses']==variants['baseline'][1]['responses']==variants['current'][0]['responses']==variants['current'][1]['responses']
        summary.append(dict(block=block,order=order,**{label:{key:statistics.mean(r[key] for r in group) for key in ['wall_ms','server_cpu_seconds','client_cpu_seconds']} for label,group in variants.items()}))
    ratios=[r['current']['wall_ms']/r['baseline']['wall_ms'] for r in summary]
    bootstrap=sorted(statistics.median(random.choices(ratios,k=6)) for _ in range(5000))
    result=dict(dataset=1,scenario='burst32_4096',blocks=summary,paired_change_percent=(statistics.median(ratios)-1)*100,paired_bootstrap_95_percent=[(bootstrap[i]-1)*100 for i in [124,4874]],requests=sum(r['count'] for r in rows),baseline_mean_server_cpu=statistics.mean(r['server_cpu_seconds'] for r in rows if r['label']=='baseline'),current_mean_server_cpu=statistics.mean(r['server_cpu_seconds'] for r in rows if r['label']=='current'),baseline_mean_client_cpu=statistics.mean(r['client_cpu_seconds'] for r in rows if r['label']=='baseline'),current_mean_client_cpu=statistics.mean(r['client_cpu_seconds'] for r in rows if r['label']=='current'))
    (OUT/'abba-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
