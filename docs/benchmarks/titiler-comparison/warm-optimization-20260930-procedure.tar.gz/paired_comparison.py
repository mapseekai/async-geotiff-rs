"""Repeatable large-COG comparison; results contain no test timestamps."""
import collections, concurrent.futures, contextlib, hashlib, importlib.metadata, json
import math, os, pathlib, platform, socket, statistics, subprocess, sys, threading, time
import paired_harness as h
ROOT = pathlib.Path(__file__).resolve().parent
ITEMS = json.loads((ROOT/'datasets.json').read_text())

def batch_coordinates(item):
    z=min(item['viewport_zoom']+1,item['maxzoom'])
    lon,lat=item['center']; n=2**z
    x=int((lon+180)/360*n); y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n)
    return [[z,tx,ty] for ty in range(y-1,y+3) for tx in range(x-3,x+5)]

def pair_burst(engine,item,round_id):
    coords=batch_coordinates(item)
    paths=[h.tile_path(engine,item,c) for c in coords]
    with h.server(engine,ROOT) as (port,_), concurrent.futures.ThreadPoolExecutor(max_workers=32) as pool:
        records=[]
        for phase in ['first','second']:
            ready=threading.Barrier(33); release=threading.Event()
            def fetch(path):
                ready.wait(timeout=15); release.wait(timeout=15)
                return h.request(port,path)
            futures=[pool.submit(fetch,path) for path in paths]
            ready.wait(timeout=15); started=time.perf_counter(); release.set()
            results=[f.result(timeout=45) for f in futures]
            elapsed=(time.perf_counter()-started)*1000
            records.append((phase,elapsed,results,h.stats(engine,port)))
        for phase,elapsed,results,cache in records:
            for r in results: h.decode(r)
            errors=sum(r['status']!=200 or 'error' in r or r.get('visible_fraction',0)<=0 for r in results)
            h.emit(ROOT,dict(scenario='burst32',engine=engine,file=item['file'],round=round_id,
                phase=phase,zoom=coords[0][0],coords=coords,concurrency=32,count=len(results),load_ms=elapsed,
                errors=errors,visible_tiles=sum(r.get('visible_fraction',0)>0 for r in results),
                total_bytes=sum(r['bytes'] for r in results),cache=cache,tiles=results))
            print('BURST32',round_id,engine,item['file'],phase,round(elapsed,2),'errors',errors,flush=True)

def main():
    for port in [18980,18981,18982]:
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.2):
                raise RuntimeError(f'Port {port} is already used')
        except ConnectionRefusedError: pass
    for item in ITEMS:
        p=h.RUST/'data'/item['file']
        assert p.stat().st_size==item['bytes'],str(p)
        with h.rasterio.open(p) as ds:
            assert (ds.width,ds.height,ds.count)==(item['width'],item['height'],item['count'])
    manifest={'machine':{'model':'Mac mini','cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),
        'logical_cpus':os.cpu_count(),'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),
        'os':platform.mac_ver()[0],'architecture':platform.machine()},
        'rust_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=h.RUST,text=True).strip(),
        'titiler_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=h.TITILER,text=True).strip(),
        'rust_version':subprocess.check_output(['rustc','--version'],text=True).split(' (')[0],
        'python':platform.python_version(),'gdal':h.rasterio.__gdal_version__,
        'packages':{name:importlib.metadata.version(name) for name in ['titiler-core','titiler-application','rio-tiler','rasterio','uvicorn','fastapi','numpy']},
        'binary_sha256':hashlib.sha256((ROOT/'rust-server').read_bytes()).hexdigest(),
        'single_pairs':10,'viewport_pairs':5,'burst_pairs':5,
        'parameters':{'tilesize':256,'format':'png','tms':'WebMercatorQuad','resampling':'nearest','reproject':'nearest','viewport_concurrency':6},
        'gdal_environment':{'GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR','GDAL_HTTP_MERGE_CONSECUTIVE_RANGES':'YES','GDAL_CACHEMAX':'512','GDAL_HTTP_TIMEOUT':'20'},
        'cold_definition':'New renderer process per pair; startup excluded; disk cache not purged',
        'warm_definition':'Same request(s), same renderer process; no client response cache',
        'processes':'One renderer process at a time; one TiTiler Uvicorn worker; default internal CPU parallelism'}
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('ASYNC_GEOTIFF_'): env.pop(k)
    env.update(RUST_LOG='off',ASYNC_GEOTIFF_BIND='127.0.0.1:18980')
    browser=None; origin=None
    with (ROOT/'origin.log').open('wb') as log:
        try:
            origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
            for _ in range(500):
                if origin.poll() is not None: raise RuntimeError('Origin exited')
                try:
                    with socket.create_connection(('127.0.0.1',18980),timeout=.05): break
                except OSError: time.sleep(.01)
            else: raise RuntimeError('Origin not ready')
            (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
            for r in range(10):
                for ix,item in enumerate(ITEMS):
                    for engine in (['rust','titiler'] if (r+ix)%2==0 else ['titiler','rust']):
                        h.pair_single(engine,item,r,ROOT)
            with (ROOT/'browser.log').open('w') as blog:
                browser=subprocess.Popen(['node',str(ROOT/'browser.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=blog,text=True)
                hello=json.loads(browser.stdout.readline()); assert hello.get('ready'),hello
                manifest['browser']=hello['browser']; (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
                print('BROWSER',hello,flush=True)
                for r in range(5):
                    for ix,item in enumerate(ITEMS):
                        for z in sorted(set([item['viewport_zoom'],item['maxzoom']])):
                            for engine in (['rust','titiler'] if (r+ix)%2==0 else ['titiler','rust']):
                                h.pair_viewport(engine,item,z,r,ROOT,browser,cache_disabled=True)
            browser.stdin.close(); browser.wait(timeout=10); browser=None
            for r in range(5):
                for ix,item in enumerate(ITEMS):
                    for engine in (['rust','titiler'] if (r+ix)%2==0 else ['titiler','rust']):
                        pair_burst(engine,item,r)
            print('COMPLETE',flush=True)
        finally:
            if browser:
                browser.terminate()
                try: browser.wait(timeout=5)
                except subprocess.TimeoutExpired: browser.kill(); browser.wait()
            if origin:
                origin.terminate()
                try: origin.wait(timeout=5)
                except subprocess.TimeoutExpired: origin.kill(); origin.wait()
            h.POOL.shutdown(wait=True)

if __name__=='__main__': main()
