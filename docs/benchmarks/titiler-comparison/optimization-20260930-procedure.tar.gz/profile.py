import json,os,pathlib,socket,subprocess,time
import harness as h
R=pathlib.Path(__file__).resolve().parent
items=json.loads(pathlib.Path('/private/tmp/large-cog-raster-style-20260930/datasets.json').read_text())
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2):raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError:pass
env=os.environ.copy();env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
with (R/'origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  for item in items:
   with h.server('rust',R) as (port,_):
    for phase in ['first','second']:
     q=h.request(port,h.tile_path('rust',item,item['tile']));h.decode(q)
     assert q['status']==200 and 'error' not in q,q
     print(item['file'],phase,q['elapsed_ms'],flush=True)
 finally:
  origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
