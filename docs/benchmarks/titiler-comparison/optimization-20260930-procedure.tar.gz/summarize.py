import collections,gzip,hashlib,json,pathlib,statistics,tarfile
R=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/Users/zhang/code/async-geotiff-rs')
items=json.loads((R/'datasets.json').read_text());names={x['file']:f'D{i+1}' for i,x in enumerate(items)}
raw=[];groups=collections.defaultdict(list);pixels=collections.defaultdict(set);counts={};coords={}
assert (R/'paired-progress.log').read_text().rstrip().endswith('COMPLETE')
for label in ['before','after']:
 records=[json.loads(s) for s in (R/'paired'/label/'raw.jsonl').read_text().splitlines()]
 assert dict(collections.Counter(x['scenario'] for x in records))=={'single':100,'viewport':100,'burst32':50}
 counts[label]=collections.Counter()
 coords[label]={}
 for r in records:
  z=r.get('zoom',r.get('coord',[None])[0]);groups[(r['scenario'],r['file'],z,r['phase'],label)].append(r)
  coords[label][(r['scenario'],r['file'],z,r['phase'],r['round'])]=r.get('coords',r.get('coord'))
  tiles=[r] if r['scenario']=='single' else r['tiles']
  for tile in tiles:
   assert tile['status']==200 and 'error' not in tile and tile['width']==tile['height']==256 and tile['visible_fraction']>0
   counts[label][r['scenario']]+=1
  if r['scenario']=='viewport':assert r['network_requests']==16 and r['cache_hits']==0 and r['visible_tiles']==16 and r['errors']==0
  else:
   cs=[r['coord']] if r['scenario']=='single' else r['coords']
   for coord,t in zip(cs,tiles):pixels[(r['file'],tuple(coord))].add(t['pixel_sha256'])
  raw.append(dict(r,version=label))
 assert sum(counts[label].values())==3300
assert coords['before']==coords['after']
assert all(len(v)==1 for v in pixels.values())
for item in items:
 key=hashlib.sha256(item['file'].encode()).hexdigest()[:12]
 assert (R/'paired/before/samples'/f'{key}-rust.png').read_bytes()==(R/'paired/after/samples'/f'{key}-rust.png').read_bytes()
rows=[]
for scenario,file,z,phase in sorted({k[:4] for k in groups}):
 metric='elapsed_ms' if scenario=='single' else 'load_ms';before=groups[(scenario,file,z,phase,'before')];after=groups[(scenario,file,z,phase,'after')]
 a=statistics.median(x[metric] for x in before);b=statistics.median(x[metric] for x in after)
 rows.append(dict(scenario=scenario,dataset=names[file],file=file,zoom=z,phase=phase,pairs=len(before),before_ms=a,after_ms=b,change_percent=(b/a-1)*100,before_response_bytes=statistics.median(x.get('total_bytes',x.get('bytes')) for x in before),after_response_bytes=statistics.median(x.get('total_bytes',x.get('bytes')) for x in after)))
assert len(rows)==40
assert all(r['before_response_bytes']==r['after_response_bytes'] for r in rows)
checks={'all_6600_responses_valid':True,'all_browser_cache_checks_passed':True,'matching_coordinates':True,'all_single_and_burst_pixels_exact_across_versions_and_repetitions':True,'center_png_bytes_exact':True,'response_sizes_unchanged':True}
summary={'environment':json.loads((R/'meta.json').read_text()),'datasets':items,'rows':rows,'request_counts':counts,'checks':checks}
(R/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
dest=repo/'docs/benchmarks/titiler-comparison';(dest/'optimization-20260930-results.json').write_text((R/'summary.json').read_text())
with (dest/'optimization-20260930-raw.jsonl.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in raw).encode())
doc=['# Raster Style RGB 性能退化分析与优化','',
'## MAP-244 的含义','',
'MAP-244 的原问题是 Raster Style 迁移后 RGB 渲染失去类型专用快路径：重复执行表达式、提升整幅源图为 F64，并对每个波段重复计算 warp 几何。此前已经恢复 UInt8/UInt16 LUT、共享几何、独立 NoData，并优化浮点缩放、统计样本和分块计算。该 issue 保留打开，用于跟踪残余浮点 RGB 和端到端性能差距；旧描述中的耗时是不同阶段的历史测量，不能当成当前实测。','',
'## 本次确认的开销与改动','',
'1. SDK 首次解析时懒加载 Q2 参数表并编译内置 JSON Schema。五个全新进程的阶段日志中，D2～D5 首次 parse 为 2.38～2.68 ms，后续请求为 0.06～0.10 ms；D1 的首轮为 6.27 ms。`AppState::new` 现在用内置合法 Q2 样式预热，修改后 D2～D5 首次 parse 为 0.05～0.07 ms、D1 为 0.14 ms。初始化移到启动阶段，校验仍完整执行；这降低首请求延迟，不代表减少了初始化总工作。','',
'2. `warp_dependencies` 对同投影、nearest、无 NoData 的 UInt8/UInt16 输入，即使使用全部源波段，也会先 `select` 复制数据和掩膜。现在完整依赖集合直接复用源图进入现有 warp；子集仍先选择，跨投影、有 NoData 和其他类型保持原路径。合成 U8 微基准中，1024² 源图缩到 256² 的 copy+warp 约 710 us，借用源图约 59 us；512² 分别约 74 和 61 us。该微基准不等同于真实 HTTP 收益。','',
'只增加两个生产分支（初始化调用及完整波段判定），没有新增依赖或缓存，没有改变像素量化、拉伸、统计精度、PNG 编码或内存预算。','',
'## 真实数据修改前后配对测试','',
'2026-09-30，使用原五份大型 COG、固定 RGB 波段与范围、nearest、WebMercatorQuad、256 PNG。每个数据／轮次交替运行 before 和 after，单次只运行一个渲染进程，共 10 对单瓦片、每级别 5 对浏览器视口、5 对 32 并发批次。每版本 3300/3300 成功，共 6600 个有效响应。两边均为默认 features 的 release 构建，未开启 perf-tracing，未在计时期间编译；同一个本地 Range origin，启动时间不计入，OS 文件缓存未清空。','',
'相比之前的顺序跨版本测量，本次交替轮次更适合判断此次补丁的收益；仍是未隔离桌面，未做统计显著性检验。没有重跑 TiTiler，因此下表只比较此次优化前后的 Rust。','',
'以下均为中位数，变化为正表示更慢、负表示更快；D1/D2 不合并为独立场景总体统计。','']
for scenario,label in [('single','单瓦片'),('viewport','浏览器 16 瓦片'),('burst32','32 并发批次')]:
 doc+=['### '+label,'','| 数据 | z | 首次 before → after（ms） | 变化 | 二次 before → after（ms） | 变化 |','|---|---:|---:|---:|---:|---:|']
 for file,z in sorted({(r['file'],r['zoom']) for r in rows if r['scenario']==scenario},key=lambda k:(names[k[0]],k[1])):
  a=next(r for r in rows if (r['scenario'],r['file'],r['zoom'],r['phase'])==(scenario,file,z,'first'));b=next(r for r in rows if (r['scenario'],r['file'],r['zoom'],r['phase'])==(scenario,file,z,'second'))
  doc.append(f"| {names[file]} | {z} | {a['before_ms']:.2f} → {a['after_ms']:.2f} | {a['change_percent']:+.1f}% | {b['before_ms']:.2f} → {b['after_ms']:.2f} | {b['change_percent']:+.1f}% |")
 doc+=['']
doc+=['## 结果与剩余边界','',
'首次单瓦片耗时降低 13～34%，首次浏览器视口降低 3～15%，首次 32 并发批次降低 3～26%。热请求没有普遍提升：D4 详细视口二次为 10.20 → 10.50 ms（+2.9%）；D1 热单瓦片为 1.81 → 2.09 ms（+15.2%，约 +0.28 ms），这条跨投影路径不执行新增的完整波段分支，原因尚未确认，仍需跟踪。不得声称全部退化已经消除，也不能用本轮 D4 的 25.20 ms 直接对上次非配对的 41.90 ms 宣称收益。','',
'单瓦片及并发批次的所有匹配坐标、首次／二次和重复轮次的解码像素哈希一致；五个中心 PNG 压缩字节完全一致。浏览器全部请求均为 256²、可见且禁用客户端缓存；响应大小完全不变。新增单元测试覆盖 UInt8/UInt16、通道重排、掩膜及边界输出，与原选择复制路径一致。','',
'库 all-features 回归 290 通过、2 忽略；Raster Style 集成 10、review regressions 23、backpressure 3、serve 20 通过，共 346 项通过。严格库及 serve Clippy、fmt、diff 检查通过。最初沙箱运行中 6 个网络测试被系统权限阻止，放开本地网络后同一套测试全部通过。','',
'源码改动尚未提交。正式基准原记录保留；结构化配对结果见 [optimization-20260930-results.json](benchmarks/titiler-comparison/optimization-20260930-results.json)，逐请求记录见 [原始记录](benchmarks/titiler-comparison/optimization-20260930-raw.jsonl.gz)。脚本、补丁、构建与测试日志见 [过程归档](benchmarks/titiler-comparison/optimization-20260930-procedure.tar.gz)。','']
(repo/'docs/raster-style-performance-optimization.md').write_text('\n'.join(doc))
main=repo/'docs/performance-comparison-titiler.md';s=main.read_text();note='第 1～10 节保留优化前的正式复跑记录；随后两处性能改动及交替配对复测见 [Raster Style 性能优化报告](raster-style-performance-optimization.md)。\n\n'

if note not in s:s=s.replace('复跑日期：',note+'复跑日期：',1)
main.write_text(s)
with tarfile.open(dest/'optimization-20260930-procedure.tar.gz','w:gz') as t:
 for file in ['REPRODUCE.md','meta.json','optimization.patch','datasets.json','paired_harness.py','paired_comparison.py','paired_bench.py','summarize.py','browser.cjs','profile.py','harness.py','raster_cost_probe.rs','titiler_comparison_bench.rs','cost-before.txt','stage-before.log','rust-server.log','profile.log','profile-after.log','paired-progress.log','production-build.log','tests-lib-unrestricted.log','tests-http.log','clippy.log','fmt.log']:
  t.add(R/file,arcname=file)
print('Checks',checks)
for scenario in ['single','viewport','burst32']:
 for phase in ['first','second']:
  rs=[r['change_percent'] for r in rows if r['scenario']==scenario and r['phase']==phase];print(scenario,phase,min(rs),max(rs))
