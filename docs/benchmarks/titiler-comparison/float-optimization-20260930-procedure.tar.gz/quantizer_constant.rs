#[inline]
fn byte(value: f64) -> u8 {
    let t = 255.0 * value.clamp(0.0, 1.0);
    let half = t.floor() + 0.5;
    let t = if (t - half).abs() <= 1e-10 { half } else { t };
    (t + 0.5).floor() as u8
}

pub(crate) fn normalize(x: f64, lo: f64, hi: f64) -> f64 {
    if x <= lo {
        return 0.0;
    }
    if x >= hi {
        return 1.0;
    }
    if (hi - lo).is_finite() {
        (x - lo) / (hi - lo)
    } else {
        (x / 2.0 - lo / 2.0) / (hi / 2.0 - lo / 2.0)
    }
}

/// Multiplication suffices away from byte boundaries. Near a half step use
/// the original division and quantizer, including its 1e-10 tie tolerance.
#[inline]
fn range_byte(value: f64, (lo, hi, span, inverse): (f64, f64, f64, f64)) -> u8 {
    if lo == hi && value == lo {
        return 128;
    }
    if value <= lo {
        return 0;
    }
    if value >= hi {
        return 255;
    }
    if !span.is_finite() || !inverse.is_finite() {
        return byte(normalize(value, lo, hi));
    }
    let scaled = 255.0 * ((value - lo) * inverse);
    let rounded = (scaled + 0.5).floor();
    // Even a subnormal reciprocal has <1e-12 byte error on an interior
    // sample. The margin also encloses the quantizer's snapping tolerance.
    if ((scaled - rounded).abs() - 0.5).abs() < 1e-8 {
        byte((value - lo) / span)
    } else {
        rounded as u8
    }
}

#[inline]
fn scaled_byte(value: f64, (lo, hi, span, scale): (f64, f64, f64, f64)) -> u8 {
    if lo == hi && value == lo {
        return 128;
    }
    if value <= lo {
        return 0;
    }
    if value >= hi {
        return 255;
    }
    if !span.is_finite() || !scale.is_finite() {
        return byte(normalize(value, lo, hi));
    }
    let scaled = (value - lo) * scale;
    let rounded = (scaled + 0.5).floor();
    // Even a subnormal reciprocal has <1e-12 byte error on an interior
    // sample. The margin also encloses the quantizer's snapping tolerance.
    if ((scaled - rounded).abs() - 0.5).abs() < 1e-8 {
        byte((value - lo) / span)
    } else {
        rounded as u8
    }
}


#[inline]
fn cast_byte(value: f64, (lo, hi, span, scale): (f64, f64, f64, f64)) -> u8 {
    if lo == hi && value == lo {
        return 128;
    }
    if value <= lo {
        return 0;
    }
    if value >= hi {
        return 255;
    }
    if !span.is_finite() || !scale.is_finite() {
        return byte(normalize(value, lo, hi));
    }
    let scaled = (value - lo) * scale;
    let rounded = (scaled + 0.5) as u8;
    // Even a subnormal reciprocal has <1e-12 byte error on an interior
    // sample. The margin also encloses the quantizer's snapping tolerance.
    if ((scaled - f64::from(rounded)).abs() - 0.5).abs() < 1e-8 {
        byte((value - lo) / span)
    } else {
        rounded
    }
}


fn main() { let values: Vec<f64>=(0..196608).map(|i| 0.1+((i*61)%25400) as f64/100.).collect(); for scaled in [0,1,2] { let start=std::time::Instant::now(); let mut out=vec![0u8;values.len()]; for _ in 0..200 { for (x,&v) in out.iter_mut().zip(&values) { *x=if scaled == 1 {scaled_byte(v,(0.,255.,255.,1.))} else if scaled == 2 {cast_byte(v,(0.,255.,255.,1.))} else {range_byte(v,(0.,255.,255.,1./255.))}; } std::hint::black_box(&out); } println!("scaled={} us={}",scaled,start.elapsed().as_secs_f64()*1e6/200.); } }
