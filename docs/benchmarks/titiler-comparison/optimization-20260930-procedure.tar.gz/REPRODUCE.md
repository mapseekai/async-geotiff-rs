# Alternating large-COG optimization benchmark

The before renderer is the unmodified 56b8d610fa68e6b3d8998f92f83508737ab35e6d
release benchmark wiring. The after renderer includes optimization.patch.
meta.json records both executable SHA-256 values, build parameters, and source
hashes. Both measured binaries have default features (perf-tracing disabled).
The stage logs were measured separately with perf-tracing enabled and debug
logging; they are diagnostic only.

To repeat on the original machine, use a new scratch directory, the same five
files under /Users/zhang/code/async-geotiff-rs/data, and the existing TiTiler
Python environment / Playwright installation. Rebuild before-server from the
base commit in an isolated checkout, and after-server from the patched checkout.
For each build, copy titiler_comparison_bench.rs into examples and point its
mod server path at that checkout's examples/serve/server.rs. Build with:

    cargo build --release --example serve --example titiler_comparison_bench

Save the temporary example binary as before-server or after-server. Rebuild
the original checkout's serve binary for the shared Range origin. Remove the
temporary example afterwards. Do not rebuild or compile during timed rounds.
No executables or datasets are included in this archive.

With ports 18980 and 18981 unused, from the extracted directory:

    PYTHONWARNINGS=ignore /Users/zhang/code/titiler/.venv/bin/python paired_bench.py > paired-progress.log 2>&1
    PYTHONWARNINGS=ignore /Users/zhang/code/titiler/.venv/bin/python summarize.py

The driver requires fresh paired/before and paired/after output directories;
it refuses to append to an existing run. It alternates versions by dataset and
round and preserves first/second request pairs. The aggregate script also
publishes repository documentation at its original absolute repo path; keep a
copy of existing report files if independently rerunning that publication step.
Startup is excluded from request timing. Schema prewarming moves one-time work
to startup; it does not remove validation or reduce that initialization cost.
