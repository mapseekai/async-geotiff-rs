import sys,json,pathlib,os,socket,subprocess,time
sys.path.insert(0,'/private/tmp/raster-style-opt6')
import harness as h
R=pathlib.Path(__file__).resolve().parent
item=json.loads((R/'datasets.json').read_text())[0]
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2):raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError:pass
env=os.environ.copy()
for k in list(env):
 if k.startswith('ASYNC_GEOTIFF_'):env.pop(k)
env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
with (R/'profile-origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   if origin.poll() is not None:raise RuntimeError('origin exited')
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  for n in range(10):
   for label in (['before','after'] if n%2==0 else ['after','before']):
    path=R/f'profile-{label}';path.mkdir(exist_ok=True);h.ROOT=path
    (path/'rust-server').write_bytes((R/f'profile-{label}-server').read_bytes());(path/'rust-server').chmod(0o755)
    with h.server('rust',path) as (port,_):
     for _ in range(11):
      q=h.request(port,h.tile_path('rust',item,item['tile']));assert q['status']==200,q
    print(n,label,flush=True)
 finally:origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
