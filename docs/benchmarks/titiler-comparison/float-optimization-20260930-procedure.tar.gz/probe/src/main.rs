use std::{hint::black_box, time::Instant};
use ndarray::Array3;
use serde_json::json;
fn timed(mut work: impl FnMut(), count: usize) -> f64 {
    for _ in 0..10 {work();}
    let now=Instant::now();
    for _ in 0..count {work();}
    now.elapsed().as_secs_f64()*1e6/count as f64
}
fn main() {
    for (name,old,new) in [
        ("rgb_linear", "bidx=1&bidx=2&bidx=3&rescale=0,255", "version=2.0&type=rgb&bidx=1&bidx=2&bidx=3&method=linear&rescale=0,255"),
        ("gray_linear", "bidx=1&rescale=0,255", "version=2.0&type=gray&bidx=1&method=linear&rescale=0,255"),
    ] {
        let old_us=timed(||{black_box(before::style::TileStyle::from_query(black_box(old)).unwrap());},10000);
        let new_us=timed(||{black_box(after::style::TileStyle::from_raster_query(black_box(new)).unwrap());},10000);
        println!("{}",json!({"scenario":"parse","style":name,"before_us":old_us,"after_us":new_us}));
    }
    for size in [256usize,1024] {
        for dtype in ["u8","u16","f64"] {
            let pixels=Array3::from_shape_fn((3,size,size),|(b,r,c)| 1.+((b*61+r*3+c)%254) as f64);
            let old=before::pixel::ImageData {
                pixels: match dtype {"u8"=>before::pixel::PixelData::U8(pixels.mapv(|v|v as u8)),"u16"=>before::pixel::PixelData::U16(pixels.mapv(|v|(v*100.) as u16)),_=>before::pixel::PixelData::F64(pixels.clone())},
                mask:None,nodata:None,crs:before::crs::Crs::epsg(3857),bbox:before::bounds::Bbox::new(0.,0.,size as f64,size as f64),transform:before::bounds::GeoTransform::from_gdal(&[0.,1.,0.,size as f64,0.,-1.])
            };
            let new=after::pixel::ImageData {
                pixels: match dtype {"u8"=>after::pixel::PixelData::U8(pixels.mapv(|v|v as u8)),"u16"=>after::pixel::PixelData::U16(pixels.mapv(|v|(v*100.) as u16)),_=>after::pixel::PixelData::F64(pixels)},
                mask:None,nodata:None,crs:after::crs::Crs::epsg(3857),bbox:after::bounds::Bbox::new(0.,0.,size as f64,size as f64),transform:after::bounds::GeoTransform::from_gdal(&[0.,1.,0.,size as f64,0.,-1.])
            };
            let hi=if dtype=="u16" {25500} else {255};
            let ranges=format!("rescale=0,{hi}&rescale=0,{hi}&rescale=0,{hi}");
            let s1=before::style::TileStyle::from_query(&format!("bidx=1&bidx=2&bidx=3&{ranges}&tilesize={size}")).unwrap();
            let s2=after::style::TileStyle::from_raster_query(&format!("version=2.0&type=rgb&bidx=1&bidx=2&bidx=3&method=linear&{ranges}&tilesize={size}")).unwrap();
            let c1=before::style::compile(&s1).unwrap();let c2=after::style::compile(&s2).unwrap();
            let a=before::render::pipeline::render(&old,&c1).unwrap();let b=after::render::pipeline::render(&new,&c2).unwrap();
            let a=image::load_from_memory(&a).unwrap().to_rgba8();let b=image::load_from_memory(&b).unwrap().to_rgba8();
            let exact=a.as_raw()==b.as_raw();
            let max_error=a.as_raw().iter().zip(b.as_raw()).map(|(x,y)|x.abs_diff(*y)).max().unwrap();
            assert!(max_error<=1,"render output changed beyond rounding: {size} {dtype} {max_error}");
            let n=if size==256 {200} else {20};
            let old_us=timed(||{black_box(before::render::pipeline::render(black_box(&old),black_box(&c1)).unwrap());},n);
            let new_us=timed(||{black_box(after::render::pipeline::render(black_box(&new),black_box(&c2)).unwrap());},n);
            println!("{}",json!({"scenario":"render_encode","dtype":dtype,"size":size,"before_us":old_us,"after_us":new_us,"exact_rgba":exact,"rgba_max_error":max_error}));
        }
    }
}
