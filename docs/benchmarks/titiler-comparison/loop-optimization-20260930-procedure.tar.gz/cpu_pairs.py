import pathlib,json,subprocess,statistics
R=pathlib.Path(__file__).resolve().parent
rows=[]
for n in range(10):
 for label in (['before','after'] if n%2==0 else ['after','before']):
  result=subprocess.check_output([str(R/f'cpu-{label}')],text=True)
  for line in result.splitlines():rows.append(dict(json.loads(line),version=label,round=n))
  print(n,label,flush=True)
(R/'cpu-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
for size in [256,1024]:
 for dtype in ['u8','u16','f64']:
  a=[r for r in rows if r.get('size')==size and r.get('dtype')==dtype and r['scenario']=='render_encode']
  for v in ['before','after']:
   x=[r for r in a if r['version']==v]
   print(size,dtype,v,statistics.median(r['after_us'] for r in x),'legacy',statistics.median(r['before_us'] for r in x),flush=True)
