import collections, gzip, hashlib, json, pathlib, shutil, statistics, tarfile
import numpy as np
import rasterio
R=pathlib.Path(__file__).resolve().parent
C=pathlib.Path('/private/tmp/large-cog-legacy-control-20260930')
repo=pathlib.Path('/Users/zhang/code/async-geotiff-rs')
new=json.loads((R/'results.json').read_text()); control=json.loads((C/'results.json').read_text())
key=lambda r:(r['scenario'],r['dataset'],r['zoom'],r['engine'],r['phase'])
cr={key(r):r for r in control['aggregates']}; nr={key(r):r for r in new['aggregates']}
comparisons=[]
for r in new['aggregates']:
 if r['engine']!='rust': continue
 k=key(r);tk=(*k[:3],'titiler',k[-1]);previous=cr[tk]['median_ms']/cr[k]['median_ms'];current=nr[tk]['median_ms']/r['median_ms']
 comparisons.append(dict(scenario=r['scenario'],dataset=r['dataset'],zoom=r['zoom'],phase=r['phase'],legacy_rust_ms=cr[k]['median_ms'],current_rust_ms=r['median_ms'],rust_change_percent=(r['median_ms']/cr[k]['median_ms']-1)*100,legacy_titiler_ms=cr[tk]['median_ms'],current_titiler_ms=nr[tk]['median_ms'],titiler_change_percent=(nr[tk]['median_ms']/cr[tk]['median_ms']-1)*100,legacy_titiler_over_rust=previous,current_titiler_over_rust=current))
assert len(comparisons)==40
assert new['datasets']==control['datasets']
assert all(new['checks'].values()) and all(control['checks'].values())
assert all(r['current_titiler_over_rust']>1 and r['legacy_titiler_over_rust']>1 for r in comparisons)
changes=[]
raws={}
for label,root in [('current',R),('legacy',C)]:
 records=[json.loads(s) for s in (root/'raw.jsonl').read_text().splitlines()]
 raws[label]={(r['file'],r['engine']):r for r in records if r['scenario']=='single' and r['phase']=='first' and r['round']==0}
for i,item in enumerate(new['datasets']):
 sample=hashlib.sha256(item['file'].encode()).hexdigest()[:12]
 for engine in ['rust','titiler']:
  arrays={}
  for label,root in [('current',R),('legacy',C)]:
   with rasterio.open(root/'samples'/f'{sample}-{engine}.png') as ds: a=np.concatenate([ds.read()[:3],ds.dataset_mask()[None]],axis=0)
   assert hashlib.sha256(a.tobytes()).hexdigest()==raws[label][item['file'],engine]['pixel_sha256']
   arrays[label]=a
  a=arrays['legacy'];b=arrays['current'];d=b[:3].astype(np.int16)-a[:3].astype(np.int16)
  changes.append(dict(dataset=f'D{i+1}',engine=engine,exact_rgba=bool(np.array_equal(a,b)),mask_exact=bool(np.array_equal(a[3],b[3])),rgb_delta_min=int(d.min()),rgb_delta_max=int(d.max()),changed_rgb_channels=int(np.count_nonzero(d)),rgb_channel_count=int(d.size)))
new['same_session_control']={'results':'legacy-control-20260930-results.json','raw':'legacy-control-20260930-raw.jsonl.gz','rows':comparisons,'center_pixel_changes':changes,'limitation':'Full current run followed by full preserved-binary control; shared current Range origin. Not randomized cross-version pairs or an isolated style-engine benchmark.'}
(R/'results.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n')
doc=(R/'performance-comparison-titiler.md').read_text()
doc=doc.replace('## 1. 测试环境','复跑日期：2026-09-30（Asia/Shanghai）。当前 Raster Style 渲染仍在全部测试项中快于 TiTiler；数值范围已更新，UInt16 像素量化不再与 TiTiler 完全一致，见第 10 节。\n\n## 1. 测试环境',1)
doc=doc.replace('v0.11.0 本地工作区源码，release 构建；Rust 1.92.0','v0.11.0，提交 `56b8d61`，release 构建；Rust 1.92.0；Raster Style SDK 0.3.0 / 协议 2.0')
doc=doc.replace('两边保留各自默认 PNG 编码策略。','两边保留各自默认 PNG 编码策略。Rust 使用 Q2 的 `version=2.0&type=rgb&method=linear`，TiTiler 保留原有参数；重复 `bidx` / `rescale`、`tilesize=256`、`resampling=nearest`、`reproject=nearest` 均不变。')
doc=doc.replace('| 32 并发批次 | 1600/1600 | 1600/1600 |','| 32 并发批次 | 1600/1600 | 1600/1600 |\n| **合计** | **3300/3300** | **3300/3300** |')
start=doc.index('| 数据 | RGBA 完全一致 |');end=doc.index('\n\n像素一致性表',start)
quality=['| 数据 | RGBA 完全一致 | 可见掩膜一致率 | RGB 平均绝对差（0～255） | RGB 最大绝对差 | RGB P99 绝对差 |','|---|---|---:|---:|---:|---:|']
for q in new['center_tile_quality']:quality.append(f"| {q['dataset']} | {'是' if q['exact_rgba'] else '否'} | {q['mask_agreement']*100:.2f}% | {q['rgb_mae']:.6f} | {q['rgb_max_error']} | {q['rgb_p99']:.0f} |")
doc=doc[:start]+'\n'.join(quality)+doc[end:]
doc=doc.replace('完整服务表现。Rust','完整服务表现；未对桌面其他进程做隔离。Rust')
section=['## 10. Raster Style 是否实质改变对比','',
'性能优势的结论没有逆转：当前版本在 40 项匹配的数据／级别／首次或二次请求中均快于 TiTiler，两个服务均为 3300/3300 成功，响应尺寸与旧结果一致。但不能沿用旧的耗时倍数或把此次结果解释为完全无性能变化。','',
'除更新原有完整测试外，还使用原测试保留的 Rust 二进制进行同日完整对照：SHA-256 `2feb3eb28025b731085c0e0b5261883ccb31cf57a56ffc6f5b931a643077464e` 与旧记录一致，使用原有 legacy 请求。对照的每个服务同样完成 3300/3300 请求，所有图像、缓存及重复像素校验通过。当前完整测试先运行，旧二进制对照随后运行；两轮均使用当前版本的同一个 Range 服务程序。旧二进制未由当前 HEAD 重建。','',
'以下是同日对照与当前版本的 TiTiler / Rust 中位数耗时比范围（不是合并请求的总体速度）：','',
'| 场景 | 阶段 | 同日旧二进制对照 | 当前 Raster Style |','|---|---|---:|---:|']
for sc,label in [('single','单瓦片'),('viewport','浏览器 16 瓦片'),('burst32','32 并发')]:
 for phase,pl in [('first','首次'),('second','二次')]:
  rows=[r for r in comparisons if r['scenario']==sc and r['phase']==phase]
  old=[r['legacy_titiler_over_rust'] for r in rows];now=[r['current_titiler_over_rust'] for r in rows]
  section.append(f"| {label} | {pl} | {min(old):.2f}～{max(old):.2f}× | {min(now):.2f}～{max(now):.2f}× |")
section+=['','匹配行的 Rust 绝对耗时变化如下；正值为当前版本更慢，负值为更快。每行列出各数据／级别的变化范围，不把 D1、D2 当作独立场景合并统计。','',
'| 场景 | 阶段 | 当前相对同日旧二进制 |','|---|---|---:|']
for sc,label in [('single','单瓦片'),('viewport','浏览器 16 瓦片'),('burst32','32 并发')]:
 for phase,pl in [('first','首次'),('second','二次')]:
  values=[r['rust_change_percent'] for r in comparisons if r['scenario']==sc and r['phase']==phase]
  section.append(f"| {label} | {pl} | {min(values):+.1f}%～{max(values):+.1f}% |")
section+=['','单项变化达到需要单独关注的幅度：D5 单瓦片首次由 6.45 ms 变为 10.00 ms（+54.9%）；D4 详细视口首次由 25.50 ms 变为 41.90 ms（+64.3%）；D4 详细视口二次由 9.70 ms 变为 13.30 ms（+37.1%）；D2 并发批次二次由 64.18 ms 变为 43.59 ms（-32.1%）。因此，本次渲染变化没有改变速度排名，但部分请求路径的绝对性能已有明显变化，不能报告为无影响。','','上述变化是本机端到端实测，包含 Q2 解析、数据打开、渲染、编码和排队；两轮顺序运行，TiTiler 自身耗时也有变化。没有进行随机化版本配对、显著性检验或只替换渲染器的微基准，不能将差值全部归因于 Raster Style。未显式拉伸的默认 UInt16 显示、自动统计、其他渲染类型与重采样不在本次比较范围内。','',
'像素兼容性结论有明确变化：同日中心瓦片对照中，TiTiler 五份数据的 RGBA 均与旧输出相同；Rust 的 D3～D5 仍完全相同，而 D1、D2 只有 RGB 通道出现 0 或 +1 的变化，掩膜完全相同。D2 原来与 TiTiler 完全一致，现在最大差为 1、平均差约 0.506；D1 平均差由 0.003866 增至约 0.485，P99 差为 1，原有重投影路径的最大差仍为 50。当前 `src/style/raster.rs` 的字节量化采用半步向上舍入，这与上述 +1 的变化吻合。视觉差异较小，但需要逐像素相等的使用方必须计入这一变化。','',
'PNG 中心响应大小及 Rust / TiTiler 大小比与旧结果完全相同；本次没有消除 Rust 默认 PNG 更大的传输代价。','',
'2026-09-29 原结果保存在 [旧结构化结果](benchmarks/titiler-comparison/previous-20260929-results.json) 和 [旧原始记录](benchmarks/titiler-comparison/previous-20260929-raw.jsonl.gz)。同日旧二进制对照见 [对照结果](benchmarks/titiler-comparison/legacy-control-20260930-results.json) 和 [对照原始记录](benchmarks/titiler-comparison/legacy-control-20260930-raw.jsonl.gz)；当前 `results.json` 包含全部匹配行的历史变化、同日变化和中心像素变化。','']
doc=doc.replace('## 附录：请求参数与原始结果','\n'.join(section)+'\n## 附录：请求参数与原始结果')
doc+='\n复跑脚本、固定数据清单、构建日志及源码状态保存在 [过程归档](benchmarks/titiler-comparison/procedure.tar.gz)；解压后按 `REPRODUCE.md` 操作，使用已有 TiTiler 虚拟环境和 Chromium。端口 18980～18982 必须空闲，必须重新构建当前 Rust 二进制，并在全新的目录保存原始记录以避免追加到旧结果。\n'
(repo/'docs/performance-comparison-titiler.md').write_text(doc)
dest=repo/'docs/benchmarks/titiler-comparison'
assert not (dest/'previous-20260929-results.json').exists(), 'Publication already completed; preserve baseline'
for name in ['results.json','raw.jsonl.gz','source-hashes.json']:
 shutil.copy2(dest/name,dest/('previous-20260929-'+name))
 shutil.copy2(R/name,dest/name)
shutil.copy2(C/'results.json',dest/'legacy-control-20260930-results.json')
with (dest/'legacy-control-20260930-raw.jsonl.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write((C/'raw.jsonl').read_bytes())
with tarfile.open(dest/'procedure.tar.gz','w:gz') as archive:
 for name in ['REPRODUCE.md','previous-results.json','harness.py','harness.legacy.py','run_comparison.py','summarize_results.py','finish_results.py','publish_results.py','datasets.json','browser.cjs','rust_server.rs','manifest.json','source-hashes.json','working-tree.patch','previous-working-tree.patch','build.log','progress.log','summary.log','comparison.log']:
  archive.add(R/name,arcname=name)
print('Published report and benchmark artifacts.')
for r in comparisons: print(r['scenario'],r['dataset'],r['zoom'],r['phase'],f"Rust {r['rust_change_percent']:+.1f}%",f"TiTiler {r['titiler_change_percent']:+.1f}%")
