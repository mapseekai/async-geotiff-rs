"""Generate checked results for the repository documentation."""
import collections, gzip, hashlib, json, pathlib, statistics
import numpy as np
import rasterio
R=pathlib.Path(__file__).resolve().parent
items=json.loads((R/'datasets.json').read_text())
manifest=json.loads((R/'manifest.json').read_text())
raw=[json.loads(line) for line in (R/'raw.jsonl').read_text().splitlines()]
assert (R/'progress.log').read_text().rstrip().endswith('COMPLETE'), 'Run incomplete'
expected={'single':200,'viewport':200,'burst32':100}
assert dict(collections.Counter(r['scenario'] for r in raw))==expected
names={i['file']: f'D{n+1}' for n,i in enumerate(items)}
groups=collections.defaultdict(list)
for r in raw:
    z=r.get('zoom',r.get('coord',[None])[0])
    groups[(r['scenario'],r['file'],z,r['engine'],r['phase'])].append(r)
rows=[]
for (scenario,file,z,engine,phase), group in sorted(groups.items()):
    metric='elapsed_ms' if scenario=='single' else 'load_ms'
    values=[r[metric] for r in group]
    tiles=[r for r in group] if scenario=='single' else [t for r in group for t in r['tiles']]
    bad=[t for t in tiles if t['status']!=200 or 'error' in t or t.get('width')!=256 or t.get('height')!=256 or t.get('visible_fraction',0)<=0]
    sizes=[r.get('total_bytes',r.get('bytes',0)) for r in group]
    rows.append(dict(scenario=scenario,dataset=names[file],file=file,zoom=z,engine=engine,phase=phase,pairs=len(group),
        median_ms=statistics.median(values),p95_ms=float(np.percentile(values,95)),min_ms=min(values),max_ms=max(values),
        successful_requests=len(tiles)-len(bad),failed_requests=len(bad),requests=len(tiles),
        median_response_bytes=statistics.median(sizes)))
quality=[]
for item in items:
    arrays={}
    for engine in ['rust','titiler']:
        key=hashlib.sha256(item['file'].encode()).hexdigest()[:12]
        with rasterio.open(R/'samples'/f'{key}-{engine}.png') as ds:
            a=ds.read(); rgb=a[:3]; mask=ds.dataset_mask()
            arrays[engine]=np.concatenate([rgb,mask[None]],axis=0)
    a,b=arrays['rust'],arrays['titiler']; visible=(a[3]>0)&(b[3]>0)
    diff=np.abs(a[:3].astype(np.int16)-b[:3].astype(np.int16))[:,visible]
    quality.append({'dataset':names[item['file']],'file':item['file'],'exact_rgba':bool(np.array_equal(a,b)),
        'mask_agreement':float(np.mean((a[3]>0)==(b[3]>0))),'rgb_mae':float(np.mean(diff)),
        'rgb_max_error':int(np.max(diff)),'rgb_p99':float(np.percentile(diff,99))})
counts={}
for scenario in expected:
    counts[scenario]={}
    for engine in ['rust','titiler']:
        rs=[r for r in rows if r['scenario']==scenario and r['engine']==engine]
        counts[scenario][engine]={'requests':sum(r['requests'] for r in rs),'success':sum(r['successful_requests'] for r in rs),
            'errors':sum(r['failed_requests'] for r in rs)}
cache_checks=all(r['network_requests']==16 and r['cache_hits']==0 and r['visible_tiles']==16 and r['errors']==0 for r in raw if r['scenario']=='viewport')
# Repeatability is evaluated within each renderer, not from compressed PNG equality across renderers.
stable=collections.defaultdict(set)
for r in raw:
    if r['scenario']=='single': stable[(r['engine'],r['file'],tuple(r['coord']))].add(r.get('pixel_sha256'))
    if r['scenario']=='burst32':
        for coord,t in zip(r['coords'],r['tiles']): stable[(r['engine'],r['file'],tuple(coord))].add(t.get('pixel_sha256'))
summary={'environment':manifest,'datasets':items,'aggregates':rows,'request_counts':counts,'center_tile_quality':quality,
    'checks':{'browser_cache_disabled_and_all_tiles_visible':cache_checks,
        'stable_pixels_within_each_renderer':all(len(s)==1 and None not in s for s in stable.values()),
        'all_responses_valid':all(r['failed_requests']==0 for r in rows)}}
(R/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('COUNTS',json.dumps(counts)); print('CHECKS',summary['checks']); print('QUALITY',json.dumps(quality))
lookup={(r['scenario'],r['file'],r['zoom'],r['engine'],r['phase']):r for r in rows}
def get(sc,item,z,engine,phase): return lookup[sc,item['file'],z,engine,phase]
def table(sc, native=None):
    out=['| 数据 | z | Rust 首次（ms） | TiTiler 首次（ms） | Rust 二次（ms） | TiTiler 二次（ms） |',
        '|---|---:|---:|---:|---:|---:|']
    for item in items:
        z=item['maxzoom'] if sc=='single' or native else item['viewport_zoom']
        if sc=='burst32': z=min(item['viewport_zoom']+1,item['maxzoom'])
        values=[get(sc,item,z,e,p)['median_ms'] for p in ['first','second'] for e in ['rust','titiler']]
        out.append('| '+names[item['file']]+' | '+str(z)+' | '+' | '.join(f'{v:.2f}' for v in values)+' |')
    return '\n'.join(out)

doc=['# async-geotiff-rs 与 TiTiler 大型 COG 性能对比','',
'## 1. 测试环境','',
'| 项目 | 配置 |','|---|---|',
'| 机器 | Mac mini，Apple M4 |',
'| CPU | 10 核：4 个性能核、6 个能效核 |',
'| 内存 | 16 GB |',
'| 操作系统 | macOS 15.6.1，ARM64 |',
'| async-geotiff-rs | v0.11.0 本地工作区源码，release 构建；Rust 1.92.0 |',
'| TiTiler | 2.4.0；Uvicorn 0.53.0，单 worker |',
'| Python / Rasterio / GDAL | 3.12.9 / 1.5.1 / 3.12.4 |',
'| rio-tiler | 9.4.6 |',
f"| 浏览器 | Chromium {manifest['browser']}，无头模式 |",
'| 数据访问 | 同一台机器、同一份 `data/` 文件、同一个本地 HTTP Range 数据服务 |','',
'两套渲染服务交替运行，每次只运行一个渲染服务进程，保留各自默认的内部线程并行度。Rust 使用 512 MiB 解码块缓存和 512 MiB 工作内存预算。TiTiler 设置 `GDAL_CACHEMAX=512`、`GDAL_DISABLE_READDIR_ON_OPEN=EMPTY_DIR`、`GDAL_HTTP_MERGE_CONSECUTIVE_RANGES=YES`、`GDAL_HTTP_TIMEOUT=20`。这些配置不代表两者的进程总内存上限相同。','',
'## 2. 测试数据','',
'选取 `data/` 中体积最大的 5 份 COG。文件大小采用十进制单位：1 GB = 10⁹ 字节，1 MB = 10⁶ 字节。所有数据均为三波段、512×512 内部分块，并带有概览。','',
'| 编号 | 数据简称 | 文件大小 | 尺寸（像素） | 类型 | 投影 | 压缩 | 概览层数 |',
'|---|---|---:|---:|---|---|---|---:|']
aliases=['SVN3 原始投影','SVN3 Web Mercator','大型 RGB COG','JL1GF04A','JL1KF01B']
for item,alias in zip(items,aliases):
    size=f"{item['bytes']/1e9:.2f} GB" if item['bytes']>=1e9 else f"{item['bytes']/1e6:.2f} MB"
    doc.append(f"| {names[item['file']]} | {alias} | {size} | {item['width']:,} × {item['height']:,} | {item['dtype'].replace('uint','UInt')} | {item['crs']} | {item['compression'].split('.')[-1].upper()} | {len(item['overviews'])} |")
doc+=['','完整文件名：','','```text']+[names[i['file']]+'  '+i['file'] for i in items]+['```','',
'D1、D2 是同一场景的不同投影版本，用于覆盖在线重投影和同投影渲染两种路径，不作为两份独立场景进行总体统计。D3～D5 为不同尺寸的 UInt8 RGB 影像。','',
'## 3. 测试口径','',
'两边均请求 `WebMercatorQuad` 网格下的 **256×256 PNG**，选择波段 1、2、3，读取和重投影重采样都为 `nearest`。每份数据在两边使用相同的显式拉伸区间，避免自动统计与样式差异影响对比；两边保留各自默认 PNG 编码策略。','',
'**首次**：每对测试前重新启动渲染进程，待端口就绪后发出该数据的第一次瓦片请求；包含按需打开数据和生成瓦片的时间，不包含进程启动时间。**二次**：在同一进程内重复相同坐标及参数，保留服务端缓存，但禁用客户端响应缓存。macOS 文件缓存未清空，因此首次指应用层冷请求，不指完全冷磁盘读取。','',
'| 场景 | 请求规模 | 计时终点 | 重复次数 |','|---|---|---|---|',
'| 单瓦片 | 单并发，数据中心附近的一张详细级别瓦片 | 完整收到 PNG 响应 | 每份数据、每个服务 10 对首次／二次 |',
'| 浏览器视口 | 4×4 共 16 张相邻瓦片，最大并发 6 | 最后一张 PNG 完成 `createImageBitmap` 解码 | 每份数据、每个服务、每个级别 5 对 |',
'| 并发批次 | 8×4 共 32 张相邻且不同的瓦片，32 并发 | 完整收到全部 HTTP 响应 | 每份数据、每个服务 5 对 |','',
'下表耗时均为各轮次的**中位数**，越小越快。视口和并发批次记录的是整批完成时间，不是单瓦片平均耗时。请求均落在数据有效覆盖区，不将空白或失败响应视为加载成功。浏览器缓存关闭，二次视口仍向后端发出 16 次网络请求。','',
'## 4. 单瓦片请求结果','',table('single'),'',
'## 5. 浏览器视口加载结果','',
'### 5.1 概览级别','',table('viewport',False),'',
'### 5.2 详细级别','',table('viewport',True),'',
'每行均为 16 张瓦片全部完成请求、传输和图片解码的时间，不包含地图引擎的 GPU 绘制。','',
'## 6. 32 并发批次结果','',table('burst32'),'',
'每批为 32 张不同坐标的瓦片，不通过重复请求同一 URL 增加并发数。表中计时包含服务端排队和客户端完整接收，不包含响应结束后的图片校验。','',
'## 7. 成功率与图像校验','',
'| 场景 | Rust 成功／请求数 | TiTiler 成功／请求数 |','|---|---:|---:|']
for sc,label in [('single','单瓦片'),('viewport','浏览器视口（两种级别）'),('burst32','32 并发批次')]:
    c=counts[sc]; doc.append(f"| {label} | {c['rust']['success']}/{c['rust']['requests']} | {c['titiler']['success']}/{c['titiler']['requests']} |")
doc+=['',
'成功响应均校验为 256×256 PNG 且包含非透明像素。单瓦片及 32 并发批次中，同一服务、同一坐标的首次／二次及重复轮次输出像素哈希一致。浏览器场景每次均检查全部 16 张瓦片的可见性，并核对网络请求数。','',
'两套服务中心瓦片的解码后 RGBA 对比：','',
'| 数据 | RGBA 完全一致 | 可见掩膜一致率 | RGB 平均绝对差（0～255） |','|---|---|---:|---:|']
for q in quality: doc.append(f"| {q['dataset']} | {'是' if q['exact_rgba'] else '否'} | {q['mask_agreement']*100:.2f}% | {q['rgb_mae']:.6f} |")
doc+=['',
'像素一致性表只对应详细级别中心瓦片，不代表所有坐标或所有重采样算法的完整一致性验证。','',
'## 8. PNG 响应体积','',
'以下为详细级别中心瓦片的响应体积中位数。1 KiB = 1,024 字节。','',
'| 数据 | Rust（KiB） | TiTiler（KiB） | Rust / TiTiler |','|---|---:|---:|---:|']
for i in items:
    a=get('single',i,i['maxzoom'],'rust','first')['median_response_bytes']; b=get('single',i,i['maxzoom'],'titiler','first')['median_response_bytes']
    doc.append(f"| {names[i['file']]} | {a/1024:.2f} | {b/1024:.2f} | {a/b:.2f}× |")
doc+=['','## 9. 结果范围','']
for sc,label,levels in [('single','单瓦片请求',[True]),('viewport','浏览器 16 瓦片加载',[False,True]),('burst32','32 并发批次',[False])]:
    ratios={p:[] for p in ['first','second']}
    for i in items:
        for native in levels:
            z=i['maxzoom'] if sc=='single' or native else i['viewport_zoom']
            if sc=='burst32': z=min(i['viewport_zoom']+1,i['maxzoom'])
            for p in ratios: ratios[p].append(get(sc,i,z,'titiler',p)['median_ms']/get(sc,i,z,'rust',p)['median_ms'])
    doc.append(f"{label}中，TiTiler / Rust 耗时比：首次 **{min(ratios['first']):.2f}～{max(ratios['first']):.2f}×**，二次 **{min(ratios['second']):.2f}～{max(ratios['second']):.2f}×**。该范围来自上表各数据的中位数比值，不是所有请求合并后的总体加速比。")
    doc.append('')
doc+=['结果对应本机环回网络、单渲染进程、指定数据和参数下的完整服务表现。Rust 的 PNG 响应体积更大；本次未测试限速公网、多 worker 部署、整幅 TIFF 下载、持续满载吞吐量或地图绘制帧率，不能将本表耗时直接等同于这些场景。','',
'## 附录：请求参数与原始结果','',
'UInt8 数据 D3～D5 的三个波段均使用 `rescale=0,255`。UInt16 数据使用以下固定区间：','',
'| 数据 | 波段 1 | 波段 2 | 波段 3 |','|---|---|---|---|']
for i in items[:2]: doc.append('| '+names[i['file']]+' | '+' | '.join(i['rescale'])+' |')
doc+=['',
'统计结果、环境版本、各场景的瓦片坐标和请求参数见 [结构化结果](benchmarks/titiler-comparison/results.json)；逐请求记录见 [原始记录](benchmarks/titiler-comparison/raw.jsonl.gz)。','']
assert all(r['failed_requests']==0 for r in rows), 'Failures require explicit result wording'
assert all(summary['checks'].values()),summary['checks']
(R/'performance-comparison-titiler.md').write_text('\n'.join(doc))
print('REPORT',len(doc),'lines')
for sc in ['single','viewport','burst32']: print(sc,table(sc))
