use async_geotiff::{
    bounds::{Bbox, GeoTransform},
    crs::Crs,
    pixel::{ImageData, PixelData},
    style::TileStyle,
    warp::{warp, Resampling},
};
use ndarray::{Array3, Axis};
use std::{hint::black_box, time::Instant};

fn main() {
    let query = "version=2.0&type=rgb&bidx=1&bidx=2&bidx=3&method=linear&rescale=0,255&rescale=0,255&rescale=0,255&resampling=nearest&reproject=nearest&tilesize=256";
    for _ in 0..100 {
        black_box(TileStyle::from_raster_query(query).unwrap());
    }
    let start = Instant::now();
    for _ in 0..10000 {
        black_box(TileStyle::from_raster_query(query).unwrap());
    }
    println!("parse_us={:.3}", start.elapsed().as_secs_f64() * 100.);
    for size in [256, 512, 1024] {
        let src = ImageData {
            pixels: PixelData::U8(Array3::from_shape_fn((3, size, size), |(b, r, c)| {
                ((b + r + c) % 256) as u8
            })),
            mask: None,
            bbox: Bbox::new(0., 0., size as f64, size as f64),
            crs: Crs::epsg(3857),
            transform: GeoTransform::from_gdal(&[0., 1., 0., size as f64, 0., -1.]),
            nodata: None,
        };
        let bbox = Bbox::new(0.25, 0.25, size as f64 - 0.25, size as f64 - 0.25);
        for copy in [false, true] {
            let start = Instant::now();
            for _ in 0..1000 {
                let selected;
                let input = if copy {
                    selected = ImageData {
                        pixels: match &src.pixels {
                            PixelData::U8(a) => PixelData::U8(a.select(Axis(0), &[0, 1, 2])),
                            _ => unreachable!(),
                        },
                        mask: src.mask.clone(),
                        bbox: src.bbox,
                        crs: src.crs.clone(),
                        transform: src.transform,
                        nodata: None,
                    };
                    &selected
                } else {
                    &src
                };
                black_box(warp(input, &src.crs, bbox, 256, 256, Resampling::Nearest).unwrap());
            }
            println!(
                "size={size} copy={copy} warp_us={:.3}",
                start.elapsed().as_secs_f64() * 1000.
            );
        }
    }
}
