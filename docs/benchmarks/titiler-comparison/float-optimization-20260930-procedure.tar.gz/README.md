# Float / bilinear follow-up, 2026-09-30

The retained source is raster-after.rs; patch.diff applies on raster-before.rs (which already includes the earlier MAP-244 optimizations). reproject-before.rs is unchanged in this follow-up. Full code is on the recorded HEAD plus prior warm-optimization procedure archive and this patch. No commit was made.

CPU: build probe twice against before/after source, copy binaries to cpu-before/cpu-after, then `python3 cpu_pairs.py`. Cargo.toml records the archived legacy crate path; adjust paths for another machine. Synthetic 3-channel data, 0..255 (UInt16 0..25500), no mask/NoData, 10 warmups then 200/20 renders per process at 256/1024; 10 alternating processes per version. Parsing rows are incidental and excluded from render conclusions.

HTTP: build examples/titiler_comparison_bench.rs for both versions (same wrapper), copy binaries to before-server/after-server. Configure datasets.json and shared /data origin to the original five documented files. Use the SHA-checked original legacy rust-server. Set paired_harness.py repository paths and browser.cjs dependency path as needed. With ports 18980/18981 free, run `http_final_pairs.py` using the existing TiTiler venv (numpy/rasterio) and installed Playwright Chromium. It creates final-http and refuses to reuse occupied ports. Each of 10 rounds starts a new renderer per dataset/version, requests one tile 11 times, then first+warm 16-tile browser viewport, concurrency 6, cache disabled. 6450 timed HTTP requests total, 2150 per version.

Run `validate_pixels.py` separately (creates pixel-validation) to compare all 85 unique coordinates, 255 requests. Exact before/after RGBA; legacy differences measured separately. Then `summarize.py` aggregates final retained CPU + final HTTP records. Bootstrap is paired by process, 10000 resamples, seed 244. JSON after_us/before_us in CPU records mean current/linked legacy; the outer version before/after is patch version.

Recorded checks: cargo test --all-features --lib --test concurrency_backpressure --test raster_style --test review_regressions --example serve (347 pass, 2 ignored); cargo clippy --all-features --lib --example serve -- -D warnings; cargo fmt --all -- --check; git diff --check. See actual logs. Rust-skills review checked quantization boundaries, borrowed arrays, masks/NoData, no new allocations/dependencies/unsafe, and measurements before retaining optimizations. No actionable review findings.

Exploratory measurements are retained as supplementary evidence, not pooled into final estimates: scaled-only, fixed-range, and a rejected 512x512 parallel threshold experiment. The threshold made 256 F64 slower and was reverted; no production thread policy change was retained. Quantizer microprobes isolate arithmetic with synthetic inputs and are not HTTP timings.

No fresh TiTiler comparison was performed in this follow-up; the original formal TiTiler results remain unchanged. Only bilinear at viewport_zoom was measured here, not all kernels or detailed zooms. Desktop noise and process warmup remain limitations.

Verification-command clarification: strict Clippy evidence is for production library/serve. Wider test-source strict Clippy has existing MAP-233 blockers; it is not recorded as passing.
