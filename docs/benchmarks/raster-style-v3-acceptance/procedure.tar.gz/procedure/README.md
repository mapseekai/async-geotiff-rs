# Raster Style Q3 acceptance procedure

Baseline: 5d4f6554ddb0bd0998acf954f8924f8be502a6e2 (SDK 0.3.0 / Q2).
Current: a820f1268f8d58e96fca893353d23334faf3ce02 plus acceptance-source.patch.
The source/binary hashes and same-inode input metadata are in ../source-manifest.json and ../results.json after extraction beside the evidence JSON. No COGs or executables are bundled.

Use Rust 1.92.0, release fat LTO/codegen-units=1, default+webp for both versions. Build serve and load_audit separately from measurements. Save the binaries as serve-baseline/current and load_audit-baseline/current. Build logs show the first builds; the final current serve was rebuilt after both browser fixes (2m48s).

Edit ROOT, OUT and ITEMS in compare.py for the local checkout, a fresh scratch directory, and datasets.json containing the five datasets copied from source-manifest.json (remove only the added size/mtime provenance fields if desired). For each variant create OUT/<label>/data as a symlink to the same existing local data directory. All five inputs in the recorded run were the identical device/inode/size, not two downloads.

Run compare.py, style_compare.py, warm_confirm.py and abba_confirm.py sequentially, with no builds or browser load overlapping them. Ports 18380/18381 must be free; the harness refuses occupied ports and stops only its own children. All HTTP paths and profiles are in the scripts; the Q2/Q3 transport differs while rendering parameters match. OS disk cache is not purged. The first request measurement starts after listening, not process startup.

compare.py: 5 datasets x6 alternating pairs, then two 20-second rounds per variant with 32 persistent HTTP/1.1 connections. style_compare.py: U16 D0 and U8 D2, six profiles x6 pairs; percentile=2,98, stddev=2, WebP lossless=true. warm_confirm.py: D0/D1/D2 x10 alternating pairs, longer 512/1024 request batches. abba_confirm.py: D1, 6 balanced ABBA/BAAB blocks, 24 fresh processes, 1024 warmup requests followed by 4096 formal requests per process, process CPU counters before/after.

For resource/cancellation checks run the existing scripts/run_load_audit.py for each recorded load_audit binary, --samples 128 and --concurrency 4/16. CPU/build configuration and fixture hashes are retained in each load-*.json. Their source commit is explicitly annotated because the runner reports the invoking checkout HEAD.

Browser: start the final serve binary from OUT/current with ASYNC_GEOTIFF_BIND=127.0.0.1:18381 and ASYNC_GEOTIFF_MOSAIC=OUT/current/mosaic.json. Run ego-browser nodejs with browser-acceptance.mjs, using exactly one new TaskSpace for that rerun. That reconciled script uses the verified zoomstart-triggered dataset switch and resolves rendercomplete without serializing the OpenLayers event. The executed-round files retain the original harness-only timing/serialization failures; pre-layout 45 rendering states were collected in those rounds (the later visual review found width-check gaps); final acceptance supersedes them with 48 states, with no app/browser error hidden.

Discarded tool attempts are preserved separately: repeated short stress connections exhausted macOS ephemeral ports; the final stress reuses 32 connections. A reference-key collision was corrected to include the full dataset URL. Style preflight required explicit percentile/stddev and Q2 WebP lossless parameters. None of the aborted records are in the formal raw files or reported counts.

Final UI repair addendum: the full performance binaries are unchanged and are identified by source-manifest.json/results.json. Their acceptance-source.patch and performance-source.patch are equivalent. After those measurements, only the embedded HTML/CSS changed. final-source.patch and final-source-manifest.json identify the delivered binary; its Rust serve/library/Cargo sources match the measured version. post_layout_check.py separately verifies all five viewports and six styles on final versus measured binaries (920 successful requests, byte-identical). This is functional parity, not another performance measurement.

The final browser script has 48 states including 320px and 390px checks of documentElement.scrollWidth, each visible form control/status rect, and MapLibre toolbar/navigation separation. It retains the Page for visual review. After inspecting screenshots, call task.finish({keep:[]}) exactly once for that same TaskSpace. The final recorded acceptance did this successfully.
