import pathlib,json,os,socket,time,subprocess,hashlib,concurrent.futures
import paired_harness as h
R=pathlib.Path(__file__).resolve().parent
items=json.loads((R/'datasets.json').read_text());records=[]
bins={'before':R/'before-server','after':R/'after-server','legacy':pathlib.Path('/Users/zhang/code/titiler-vs-async-geotiff-bench/large-cog-comparison/rust-server')}
assert hashlib.sha256(bins['legacy'].read_bytes()).hexdigest()=='2feb3eb28025b731085c0e0b5261883ccb31cf57a56ffc6f5b931a643077464e'
for label,b in bins.items():
 path=R/label;path.mkdir(exist_ok=False)
 (path/'rust-server').write_bytes(b.read_bytes());(path/'rust-server').chmod(0o755)
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2):raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError:pass
env=os.environ.copy()
for k in list(env):
 if k.startswith('ASYNC_GEOTIFF_'):env.pop(k)
env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
def tile(label,item,coord,kernel):
 p=h.tile_path('rust',item,coord).replace('resampling=nearest',f'resampling={kernel}').replace('reproject=nearest',f'reproject={kernel}')
 if label=='legacy':p=p.replace('&version=2.0&type=rgb&method=linear','')
 return p
browser=None
with (R/'origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   if origin.poll() is not None:raise RuntimeError('origin exited')
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  with (R/'browser.log').open('w') as blog:
   browser=subprocess.Popen(['node',str(R/'browser.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=blog,text=True)
   hello=json.loads(browser.stdout.readline());assert hello.get('ready'),hello
   for n in range(10):
    for i,item in enumerate(items):
     labels=['legacy','before','after'];labels=labels[(n+i)%3:]+labels[:(n+i)%3]
     for label in labels:
      h.ROOT=R/label
      with h.server('rust',h.ROOT) as (port,_):
       for j in range(11):
        q=h.request(port,tile(label,item,item['tile'],'bilinear'));h.decode(q)
        assert q['status']==200 and 'error' not in q,q
        records.append(dict(q,version=label,scenario='single',file=item['file'],round=n,index=j))
       _,coords=h.viewport_urls('rust',item,item['viewport_zoom'])
       urls=[f'http://127.0.0.1:{port}'+tile(label,item,c,'bilinear') for c in coords]
       browser.stdin.write(json.dumps({'urls':urls,'cache_disabled':True})+'\n');browser.stdin.flush()
       result=json.loads(browser.stdout.readline());assert 'error' not in result,result
       for phase in ['first','second']:
        records.append(dict(result[phase],version=label,scenario='viewport',file=item['file'],round=n,phase=phase,coords=coords))
      print(n,item['file'],label,flush=True)
   browser.stdin.close();browser.wait(timeout=10);browser=None
 finally:
  if browser:browser.terminate();browser.wait(timeout=10)
  origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
(R/'http-pairs.json').write_text(json.dumps(records,indent=2)+'\n')
print('COMPLETE',flush=True)
