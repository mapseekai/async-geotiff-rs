import pathlib,json,os,socket,time,subprocess,hashlib,concurrent.futures
import paired_harness as h
R=pathlib.Path(__file__).resolve().parent
items=json.loads((R/'datasets.json').read_text());records=[]
bins={'before':R/'before-server','after':R/'after-server','legacy':pathlib.Path('/Users/zhang/code/titiler-vs-async-geotiff-bench/large-cog-comparison/rust-server')}
R=R/'pixel-validation';R.mkdir(exist_ok=False)
assert hashlib.sha256(bins['legacy'].read_bytes()).hexdigest()=='2feb3eb28025b731085c0e0b5261883ccb31cf57a56ffc6f5b931a643077464e'
for label,b in bins.items():
 path=R/label;path.mkdir(exist_ok=False)
 (path/'rust-server').write_bytes(b.read_bytes());(path/'rust-server').chmod(0o755)
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2):raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError:pass
env=os.environ.copy()
for k in list(env):
 if k.startswith('ASYNC_GEOTIFF_'):env.pop(k)
env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
def tile(label,item,coord,kernel):
 p=h.tile_path('rust',item,coord).replace('resampling=nearest',f'resampling={kernel}').replace('reproject=nearest',f'reproject={kernel}')
 if label=='legacy':p=p.replace('&version=2.0&type=rgb&method=linear','')
 return p

import numpy as np
pixels={};rows=[]
with (R/'origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   if origin.poll() is not None:raise RuntimeError('origin exited')
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  for label in ['legacy','before','after']:
   h.ROOT=R/label
   with h.server('rust',h.ROOT) as (port,_):
    for item in items:
     for kernel in ['nearest','bilinear']:
      _,coords=h.viewport_urls('rust',item,item['viewport_zoom'])
      coords=[item['tile']]+coords
      for coord in coords:
       q=h.request(port,tile(label,item,coord,kernel));decoded=h.decode(q)
       assert decoded and 'error' not in q,q
       pixels[(label,item['file'],kernel,tuple(coord))]=decoded[1]
       rows.append(dict(q,version=label,file=item['file'],kernel=kernel,coord=coord))
 finally:
  origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
summary=[]
for item in items:
 for kernel in ['nearest','bilinear']:
  checks=[]
  for label,f,k,c in pixels:
   if label!='after' or f!=item['file'] or k!=kernel:continue
   a=pixels[(label,f,k,c)];b=pixels[('before',f,k,c)];old=pixels[('legacy',f,k,c)]
   assert np.array_equal(a,b),(f,k,c)
   checks.append(dict(coord=c,before_after_exact=True,legacy_rgb_max_error=int(np.abs(a[:3].astype('int16')-old[:3].astype('int16')).max()),legacy_alpha_different_pixels=int(np.count_nonzero(a[3]!=old[3]))))
  summary.append(dict(file=item['file'],kernel=kernel,checks=checks))
(R/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
(R/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
print('VALID',len(rows),'all before/after exact',flush=True)
for x in summary:print(x['file'],'legacy max',max(c['legacy_rgb_max_error'] for c in x['checks']),'alpha differing',sum(c['legacy_alpha_different_pixels'] for c in x['checks']),flush=True)
