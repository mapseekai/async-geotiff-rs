"""Cold/warm HTTP comparison. Requires a shared unmodified Rust /data origin on :18980."""
import argparse, concurrent.futures, contextlib, datetime, hashlib, http.client
import json, math, os, pathlib, socket, statistics, subprocess, time
from urllib.parse import urlencode, quote
import numpy as np
import rasterio
ROOT = pathlib.Path(__file__).resolve().parent
RUST = pathlib.Path('/Users/zhang/code/async-geotiff-rs')
TITILER = pathlib.Path('/Users/zhang/code/titiler')
PORTS = {'rust':18981,'titiler':18982}
POOL = concurrent.futures.ThreadPoolExecutor(max_workers=6)
def request(port, path):
    conn = http.client.HTTPConnection('127.0.0.1',port,timeout=40)
    started = time.perf_counter()
    try:
        conn.request('GET',path,headers={'Accept-Encoding':'identity','Cache-Control':'no-cache'})
        response = conn.getresponse(); ttfb = (time.perf_counter()-started)*1000
        body = response.read()
        return {'status':response.status,'ttfb_ms':ttfb,'elapsed_ms':(time.perf_counter()-started)*1000,
                'bytes':len(body),'body':body,'content_type':response.getheader('Content-Type')}
    except Exception as exc:
        return {'status':0,'elapsed_ms':(time.perf_counter()-started)*1000,'bytes':0,'body':b'', 'error':str(exc)}
    finally: conn.close()
def tile_path(engine,item,coord):
    z,x,y = coord
    params = [('bidx',str(i)) for i in item['indexes']] + [('rescale',v) for v in item['rescale']]
    params += [('resampling','nearest'),('reproject','nearest')]
    source = ('dataset',item['file']) if engine=='rust' else ('url','http://127.0.0.1:18980/data/'+quote(item['file']))
    prefix = '/tiles' if engine=='rust' else '/cog/tiles'
    return f'{prefix}/WebMercatorQuad/{z}/{x}/{y}'+'.png?tilesize=256&'+urlencode([source]+params)
@contextlib.contextmanager
def server(engine,run):
    port = PORTS[engine]
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.1):
            raise RuntimeError(f'Port {port} already occupied; refusing to use or terminate it')
    except ConnectionRefusedError: pass
    env = os.environ.copy()
    for k in list(env):
        if k.startswith(('ASYNC_GEOTIFF_','TITILER_','GDAL_','CPL_VSIL_')): env.pop(k)
    env.update(RUST_LOG='off',GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR',GDAL_HTTP_MERGE_CONSECUTIVE_RANGES='YES',GDAL_CACHEMAX='512',GDAL_HTTP_TIMEOUT='20')
    cmd = [str(ROOT/'rust-server')] if engine=='rust' else [str(TITILER/'.venv/bin/python'),'-m','uvicorn','titiler.application.main:app','--host','127.0.0.1','--port',str(port),'--workers','1','--no-access-log','--log-level','error']
    with (run/f'{engine}-server.log').open('ab') as log:
        started=time.perf_counter(); p=subprocess.Popen(cmd,cwd=RUST if engine=='rust' else TITILER,env=env,stdout=log,stderr=log)
        try:
            while True:
                if p.poll() is not None: raise RuntimeError(f'{engine} exited {p.returncode}; see server log')
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.05): break
                except OSError:
                    if time.perf_counter()-started>40: raise TimeoutError(f'{engine} startup')
                    time.sleep(.01)
            yield port,(time.perf_counter()-started)*1000
        finally:
            p.terminate()
            try: p.wait(timeout=5)
            except subprocess.TimeoutExpired: p.kill(); p.wait()
def decode(result):
    body=result.pop('body',b'')
    if result['status']!=200:
        result['error']=result.get('error',body[:700].decode(errors='replace')); return None
    started=time.perf_counter()
    try:
        with rasterio.io.MemoryFile(body) as mem, mem.open() as ds:
            a=ds.read(); mask=ds.dataset_mask()
            rgb=a[:3] if a.shape[0]>=3 else np.repeat(a[:1],3,axis=0)
            rgba=np.concatenate([rgb,mask[None]],axis=0)
            result.update(width=ds.width,height=ds.height,visible_fraction=float(np.mean(mask>0)),
                rgb_std=float(np.std(rgb)),png_sha256=hashlib.sha256(body).hexdigest(),
                pixel_sha256=hashlib.sha256(rgba.tobytes()).hexdigest())
        result['decode_ms']=(time.perf_counter()-started)*1000
        if result['width']!=256 or result['height']!=256: result['error']='wrong PNG dimensions'
        return body,rgba
    except Exception as exc: result['error']=f'PNG decode: {exc}'; return None
def stats(engine,port):
    if engine!='rust': return None
    r=request(port,'/cache/stats')
    return json.loads(r['body']) if r['status']==200 else None
def emit(run,record):
    with (run/'raw.jsonl').open('a') as f: f.write(json.dumps(record,ensure_ascii=False)+'\n')
def pair_single(engine,item,round_id,run,scenario='single'):
    with server(engine,run) as (port,startup):
        path=tile_path(engine,item,item['tile'])
        before=stats(engine,port); first=request(port,path); mid=stats(engine,port)
        second=request(port,path); after=stats(engine,port)
    decoded=[decode(first),decode(second)]
    for phase,r,cache in [('first',first,mid),('second',second,after)]:
        emit(run,dict(engine=engine,file=item['file'],round=round_id,scenario=scenario,phase=phase,
                      coord=item['tile'],path=path,startup_ms=startup,cache_before=before,cache=cache,**r))
    if round_id==0 and decoded[0]:
        key=hashlib.sha256(item['file'].encode()).hexdigest()[:12]
        (run/'samples'/f'{key}-{engine}.png').write_bytes(decoded[0][0])
    print('SINGLE',round_id,engine,item['file'],first['status'],round(first['elapsed_ms'],2),round(second['elapsed_ms'],2),flush=True)
    return first['status']==200 and first.get('visible_fraction',0)>0 and 'error' not in first

def viewport_urls(engine,item,z):
    lon,lat=item['center']; n=2**z
    x=int((lon+180)/360*n); y=int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n)
    coords=[[z,tx,ty] for ty in range(y-1,y+3) for tx in range(x-1,x+3) if 0<=tx<n and 0<=ty<n]
    return [f'http://127.0.0.1:{PORTS[engine]}'+tile_path(engine,item,c) for c in coords],coords

def pair_viewport(engine,item,z,round_id,run,browser,cache_disabled=True):
    urls,coords=viewport_urls(engine,item,z)
    with server(engine,run) as (port,startup):
        browser.stdin.write(json.dumps({'urls':urls,'cache_disabled':cache_disabled})+'\n'); browser.stdin.flush()
        response=json.loads(browser.stdout.readline())
        if 'error' in response: raise RuntimeError(response['error'])
        cache=stats(engine,port)
    for phase in ['first','second']:
        r=response[phase]; emit(run,dict(engine=engine,file=item['file'],round=round_id,scenario='viewport' if cache_disabled else 'browser_cache',
            phase=phase,zoom=z,coords=coords,urls=urls,startup_ms=startup,cache_after_pair=cache,**r))
    print('VIEWPORT',round_id,engine,item['file'],'z',z,round(response['first']['load_ms'],2),round(response['second']['load_ms'],2),flush=True)
def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--smoke',action='store_true'); args=parser.parse_args()
    run=ROOT/'runs'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S'); (run/'samples').mkdir(parents=True)
    (ROOT/'latest-run.txt').write_text(str(run)); print('RUN',run,flush=True)
    items=[i for i in json.loads((ROOT/'datasets.json').read_text()) if 'error' not in i]
    if args.smoke: items=[i for i in items if i['file']=='TCI.tif']
    for port in [18980,18981,18982]:
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.1): raise RuntimeError(f'Port {port} in use')
        except ConnectionRefusedError: pass
    env=os.environ.copy()
    for k in list(env):
        if k.startswith('ASYNC_GEOTIFF_'): env.pop(k)
    env.update(RUST_LOG='off',ASYNC_GEOTIFF_BIND='127.0.0.1:18980')
    origin_log=(run/'origin.log').open('wb')
    origin=subprocess.Popen([str(RUST/'target/release/examples/serve')],cwd=RUST,env=env,stdout=origin_log,stderr=origin_log)
    browser=None
    try:
        for _ in range(400):
            try:
                with socket.create_connection(('127.0.0.1',18980),timeout=.05): break
            except OSError: time.sleep(.01)
        else: raise RuntimeError('Origin did not start')
        health={}
        for idx,item in enumerate(items):
            health[item['file']]={}
            for engine in (['rust','titiler'] if idx%2==0 else ['titiler','rust']):
                health[item['file']][engine]=pair_single(engine,item,0,run)
        (run/'compatibility.json').write_text(json.dumps(health,indent=2))
        selected=[i for i in items if i['bytes']>=6_000_000 and all(health[i['file']].values())]
        (run/'selected.json').write_text(json.dumps(selected,indent=2))
        for round_id in range(1,2 if args.smoke else 5):
            for item in selected:
                for engine in (['titiler','rust'] if round_id%2 else ['rust','titiler']):
                    pair_single(engine,item,round_id,run)
        # Metadata endpoints differ in TiTiler 2.x; compare only verified tile workloads.
        browser_log=(run/'browser.log').open('w')
        browser=subprocess.Popen(['node',str(ROOT/'browser.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=browser_log,text=True)
        hello=json.loads(browser.stdout.readline()); print('BROWSER',hello,flush=True)
        manifest=json.loads((ROOT/'manifest.json').read_text()); manifest.update(browser=hello,measured_at=datetime.datetime.now().astimezone().isoformat(),
            cold_definition='New renderer process per single/viewport pair. OS file cache not flushed. Metadata: new process per dataset sweep; first open of each file.',
            data_origin='Shared original Rust /data server on loopback :18980',threads='One process per renderer, default internal CPU parallelism; viewport concurrency 6',
            titiler_env={'GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR','GDAL_HTTP_MERGE_CONSECUTIVE_RANGES':'YES','GDAL_CACHEMAX':'512','GDAL_HTTP_TIMEOUT':'20'},
            dimensions='256x256 PNG; WebMercatorQuad; explicit bands/ranges; nearest read and reprojection; no output cache added',
            limitation='Desktop not isolated; disk cache not purged; full-file download and GPU/map-library painting not measured')
        (run/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        for round_id in range(1 if args.smoke else 3):
            for item in selected:
                for z in sorted(set([item['viewport_zoom'],item['maxzoom']])):
                    for engine in (['rust','titiler'] if round_id%2==0 else ['titiler','rust']):
                        pair_viewport(engine,item,z,round_id,run,browser)
        cache_items=selected if args.smoke else [i for i in selected if 'FUS_3857' in i['file'] or i['file']=='TCI.tif']
        for item in cache_items:
            for engine in ['rust','titiler']:
                pair_viewport(engine,item,item['viewport_zoom'],0,run,browser,cache_disabled=False)
        print('COMPLETE',run,flush=True)
    finally:
        if browser:
            browser.stdin.close()
            try: browser.wait(timeout=10)
            except subprocess.TimeoutExpired: browser.kill(); browser.wait()
        origin.terminate()
        try: origin.wait(timeout=5)
        except subprocess.TimeoutExpired: origin.kill(); origin.wait()
        origin_log.close(); POOL.shutdown(wait=True)
if __name__=='__main__': main()
