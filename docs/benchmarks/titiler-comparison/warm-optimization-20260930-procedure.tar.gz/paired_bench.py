import json,os,pathlib,socket,subprocess,time
import paired_harness as h
import paired_comparison as c
R=pathlib.Path(__file__).resolve().parent
items=json.loads((R/'datasets.json').read_text())
paths={label:R/'paired'/label for label in ['before','after']}
for label,path in paths.items():
 (path/'samples').mkdir(parents=True,exist_ok=False)
 (path/'rust-server').write_bytes((R/f'{label}-server').read_bytes());(path/'rust-server').chmod(0o755)
for port in [18980,18981]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=.2):raise RuntimeError(f'occupied {port}')
 except ConnectionRefusedError:pass
env=os.environ.copy()
for k in list(env):
 if k.startswith('ASYNC_GEOTIFF_'):env.pop(k)
env.update(ASYNC_GEOTIFF_BIND='127.0.0.1:18980',RUST_LOG='off')
browser=None
with (R/'paired-origin.log').open('w') as log:
 origin=subprocess.Popen([str(h.RUST/'target/release/examples/serve')],cwd=h.RUST,env=env,stdout=log,stderr=log)
 try:
  for _ in range(500):
   if origin.poll() is not None:raise RuntimeError('origin exited')
   try:
    with socket.create_connection(('127.0.0.1',18980),timeout=.05):break
   except OSError:time.sleep(.01)
  else:raise RuntimeError('origin not ready')
  for n in range(10):
   for i,item in enumerate(items):
    for label in (['before','after'] if (n+i)%2==0 else ['after','before']):
     h.ROOT=paths[label];print('VERSION',label,flush=True);h.pair_single('rust',item,n,paths[label])
  with (R/'paired-browser.log').open('w') as blog:
   browser=subprocess.Popen(['node',str(R/'browser.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=blog,text=True)
   hello=json.loads(browser.stdout.readline());assert hello.get('ready'),hello
   print('BROWSER',hello,flush=True)
   for n in range(5):
    for i,item in enumerate(items):
     for z in [item['viewport_zoom'],item['maxzoom']]:
      for label in (['before','after'] if (n+i)%2==0 else ['after','before']):
       h.ROOT=paths[label];print('VERSION',label,flush=True);h.pair_viewport('rust',item,z,n,paths[label],browser)
  browser.stdin.close();browser.wait(timeout=10);browser=None
  for n in range(5):
   for i,item in enumerate(items):
    for label in (['before','after'] if (n+i)%2==0 else ['after','before']):
     h.ROOT=paths[label];c.ROOT=paths[label];print('VERSION',label,flush=True);c.pair_burst('rust',item,n)
  print('COMPLETE',flush=True)
 finally:
  if browser:browser.terminate();browser.wait(timeout=10)
  origin.terminate();origin.wait(timeout=10);h.POOL.shutdown()
