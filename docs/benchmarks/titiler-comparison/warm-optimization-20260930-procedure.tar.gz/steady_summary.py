import json,pathlib,statistics,numpy as np
R=pathlib.Path(__file__).resolve().parent
def summarize(path):
 rows=json.loads(path.read_text());result={}
 assert len(rows)==1320 and len({r['png_sha256'] for r in rows})==1
 for phase,indices in [('second',[1]),('steady',range(2,22))]:
  values={v:[r['elapsed_ms'] for r in rows if r['version']==v and r['index'] in indices] for v in ['before','after']}
  med={v:statistics.median(a) for v,a in values.items()}
  per_round={v:np.array([statistics.median(r['elapsed_ms'] for r in rows if r['version']==v and r['index'] in indices and r['round']==n) for n in range(30)]) for v in ['before','after']}
  # Resample whole process pairs; repeated requests within a process are correlated.
  choices=np.random.default_rng(244).integers(0,30,size=(10000,30))
  boot=(np.median(per_round['after'][choices],axis=1)/np.median(per_round['before'][choices],axis=1)-1)*100
  result[phase]={'requests_per_version':len(values['before']),'before_ms':med['before'],'after_ms':med['after'],
   'pooled_change_percent':(med['after']/med['before']-1)*100,
   'per_process_median_before_ms':float(np.median(per_round['before'])),
   'per_process_median_after_ms':float(np.median(per_round['after'])),
   'per_process_change_percent':float((np.median(per_round['after'])/np.median(per_round['before'])-1)*100),
   'paired_process_bootstrap_95_percent':np.percentile(boot,[2.5,97.5]).tolist()}
 return {'requests':len(rows),'png_bytes_exact':True,'rounds':30,'rows':result}
s={'original_15_percent_recheck':summarize(R/'recheck-raw.json'),'new_optimization':summarize(R/'steady/recheck-raw.json')}
(R/'steady-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(s,indent=2))
