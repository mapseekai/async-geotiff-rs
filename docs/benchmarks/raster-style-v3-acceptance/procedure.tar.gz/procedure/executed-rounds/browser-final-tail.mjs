const fs = await import("node:fs/promises");
const assert = (await import("node:assert/strict")).default;
const out = "/tmp/raster-q3-acceptance-20261019";
const task = await taskSpace(2);
const page = task.page("p1");
const results = JSON.parse(await fs.readFile(`${out}/browser-results.json`,"utf8"));
async function completed(expected) {
  await page.waitForFunction((wanted) => performance.getEntriesByType("resource").some(e => e.name.includes("/tiles/") && e.responseStatus === 200 && Object.entries(wanted).every(([key,value]) => new URL(e.name).searchParams.get(key) === value)), expected, {timeout:30000});
}
async function record(viewer, scenario, expected = {}) {
  await completed(expected);
  if (viewer === "leaflet") await page.waitForSelector("#map img.leaflet-tile-loaded",{state:"visible"});
  if (viewer === "openlayers") await page.waitForFunction(()=>{const c=document.querySelector("#map canvas");if(!c)return false;const a=c.getContext("2d").getImageData(0,0,c.width,c.height).data;for(let i=3;i<a.length;i+=4096)if(a[i])return true;return false;},undefined,{timeout:30000});
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data = await page.evaluate(async (wanted) => {
    const entries = performance.getEntriesByType("resource").filter(e => e.name.includes("/tiles/") && e.responseStatus === 200 && Object.entries(wanted).every(([key,value]) => new URL(e.name).searchParams.get(key) === value));
    let url,response,bytes,bitmap,visible;
    for(const entry of [...entries].reverse().slice(0,16)) {
      url=entry.name;response=await fetch(url,{cache:"no-store"});bytes=await response.arrayBuffer();
      bitmap=await createImageBitmap(new Blob([bytes],{type:response.headers.get("Content-Type")}));
      const canvas=document.createElement("canvas");canvas.width=bitmap.width;canvas.height=bitmap.height;
      const ctx=canvas.getContext("2d");ctx.drawImage(bitmap,0,0);const pixels=ctx.getImageData(0,0,bitmap.width,bitmap.height).data;
      visible=0;for(let i=3;i<pixels.length;i+=4)if(pixels[i])visible++;
      if(visible)break;
    }
    const hash=[...new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))].map(x=>x.toString(16).padStart(2,"0")).join("");
    const errors=performance.getEntriesByType("resource").filter(e=>e.name.includes("/tiles/") && e.responseStatus>=400).map(e=>({url:e.name,status:e.responseStatus}));
    return {url,status:response.status,width:bitmap.width,height:bitmap.height,bytes:bytes.byteLength,sha256:hash,visibleFraction:visible/(bitmap.width*bitmap.height),tileErrors:errors,pageErrors:window.__qa.errors,unhandled:window.__qa.unhandled,viewport:innerWidth,bodyWidth:document.body.scrollWidth,expressionDisabled:document.getElementById("bidx").disabled};
  },expected);
  const params=new URL(data.url).searchParams;
  assert.equal(params.get("version"),"3.0");
  assert.equal(params.has("format"),false);assert.equal(params.has("tilesize"),false);
  assert.equal(data.status,200);assert.equal(data.tileErrors.length,0);assert.equal(data.pageErrors.length,0);assert.equal(data.unhandled.length,0);
  assert.ok(data.visibleFraction>0);assert.equal(data.bodyWidth<=data.viewport,true);
  results.push({viewer,scenario,...data});
  await fs.writeFile(`${out}/browser-results.json`,JSON.stringify(results,null,2));
  console.log(viewer,scenario,"passed",data.width,data.height);
}

await page.cdp("Page.addScriptToEvaluateOnNewDocument",{source:`window.__qa={errors:[],unhandled:[]};addEventListener("error",e=>{if(e.message)window.__qa.errors.push(e.message)});addEventListener("unhandledrejection",e=>window.__qa.unhandled.push(String(e.reason)));`});
await page.goto("http://127.0.0.1:18381/leaflet?dataset=eox_cloudless.tif&mode=single&opacity=1");
await page.waitForFunction(()=>rasterReady && cogLayer && !zooming);
const overlap = await page.evaluate(()=>new Promise(resolve=>{
 map.once("zoomstart",()=>{
  const select=document.getElementById("dataset");select.value="SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif";
  select.dispatchEvent(new Event("change",{bubbles:true}));resolve(zooming);
 });
 document.querySelector('a[aria-label="Zoom in"]').click();
}));
assert.equal(overlap,true);
await page.waitForFunction(()=>rasterReady && !zooming && map.getZoom()>=10,undefined,{timeout:30000});
assert.ok(Math.abs((await page.evaluate(()=>map.getCenter().lng))-120.14)<0.05);
await record("leaflet","switch-during-zoom-fixed",{dataset:"SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif"});
await page.screenshot({path:`${out}/leaflet-zoom-switch-fixed.png`});
await page.goto("http://127.0.0.1:18381/openlayers?dataset=SVN3-01_20250814_L2D0000203064_01_6112500050210001-FUS_cog.tif&method=minmax&opacity=1");
await page.waitForFunction(()=>rasterReady && !map.getView().getAnimating());
await page.evaluate(()=>new Promise(resolve=>{map.once("rendercomplete",resolve);map.render();}));
await page.screenshot({path:`${out}/openlayers-uint16-settled.png`});
await fs.writeFile(`${out}/browser-environment.json`,JSON.stringify(await page.evaluate(()=>({userAgent:navigator.userAgent,hardwareConcurrency:navigator.hardwareConcurrency,devicePixelRatio,viewport:[innerWidth,innerHeight]})),null,2));
console.log("FINAL browser states",results.length);
await task.finish({keep:[]});
