"""Longer warm batches to resolve noisy short acceptance samples."""
from collections import Counter
import json
import random
import statistics
import compare as bench
import style_compare as styles

OUT=bench.OUT

def main():
    assert not (OUT/'warm-confirm-raw.jsonl').exists()
    rows=[]
    for d in [0,1,2]:
        for round_id in range(10):
            for label in (['baseline','current'] if round_id%2==0 else ['current','baseline']):
                with bench.server(label):
                    item=bench.ITEMS[d];tile=bench.path(label,item,item['tile']);view=[bench.path(label,item,c) for c in bench.coordinates(item)]
                    bench.batch(label,[tile]+view,16)
                    scenarios=[('warm_single_512',[tile]*512,1),('viewport_warm_512',view[:16]*32,6),('burst32_1024',view*32,32)]
                    if d==2:
                        url=styles.request_path(label,item,'minmax');bench.batch(label,[url],1)
                        scenarios.append(('minmax_512',[url]*512,4))
                    for scenario,paths,concurrency in scenarios:
                        data=bench.batch(label,paths,concurrency)
                        counts=Counter((r['path'],r['sha256'],r['bytes']) for r in data.pop('responses'))
                        row=dict(dataset=d,label=label,round=round_id,scenario=scenario,**data,responses=[dict(path=k[0],sha256=k[1],bytes=k[2],count=v) for k,v in sorted(counts.items())])
                        rows.append(row)
                        with (OUT/'warm-confirm-raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print('long pair',d,round_id,'passed',flush=True)
    random.seed(20261019);result=[]
    for d in [0,1,2]:
        for scenario in sorted({r['scenario'] for r in rows if r['dataset']==d}):
            pairs={i:{r['label']:r for r in rows if r['dataset']==d and r['scenario']==scenario and r['round']==i} for i in range(10)}
            for p in pairs.values():assert p['baseline']['responses']==p['current']['responses'],(d,scenario)
            ratios=[p['current']['wall_ms']/p['baseline']['wall_ms'] for p in pairs.values()]
            bootstrap=sorted(statistics.median(random.choices(ratios,k=10)) for _ in range(5000))
            result.append(dict(dataset=d,scenario=scenario,pairs=10,baseline_ms=statistics.median(p['baseline']['wall_ms'] for p in pairs.values()),current_ms=statistics.median(p['current']['wall_ms'] for p in pairs.values()),paired_change_percent=(statistics.median(ratios)-1)*100,paired_bootstrap_95_percent=[(bootstrap[i]-1)*100 for i in [124,4874]]))
    (OUT/'warm-confirm-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
